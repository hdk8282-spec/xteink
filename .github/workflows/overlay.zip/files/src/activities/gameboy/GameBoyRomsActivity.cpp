#include "GameBoyRomsActivity.h"

#include <GfxRenderer.h>
#include <HalDisplay.h>
#include <HalStorage.h>
#include <I18n.h>
#include <Logging.h>

#include <algorithm>
#include <cctype>
#include <memory>

#include "MappedInputManager.h"
#include "activities/RenderLock.h"
#include "activities/gameboy/GameBoyActivity.h"
#include "activities/gameboy/GameBoyPadActivity.h"
#include "components/UITheme.h"

namespace fui = freeink::ui;

namespace {

constexpr const char* kRomDirs[] = {"/gameboy", "/roms", "/gb", "/games"};

bool isRomName(const std::string& name) {
  const size_t dot = name.find_last_of('.');
  if (dot == std::string::npos) return false;
  std::string ext = name.substr(dot + 1);
  for (char& c : ext) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return ext == "gb" || ext == "gbc";
}

}  // namespace

GameBoyRomsActivity::GameBoyRomsActivity(GfxRenderer& renderer, MappedInputManager& mappedInput)
    : UiListActivity("GameBoyRoms", renderer, mappedInput) {}

const char* GameBoyRomsActivity::headerTitle() const { return tr(STR_GAMEBOY); }

void GameBoyRomsActivity::onEnter() {
  UiListActivity::onEnter();
  rescan();
}

void GameBoyRomsActivity::rescan() {
  roms_.clear();
  for (const char* dirPath : kRomDirs) {
    if (!Storage.exists(dirPath)) continue;
    HalFile dir = Storage.open(dirPath);
    if (!dir || !dir.isDirectory()) {
      if (dir) dir.close();
      continue;
    }
    char name[160];
    for (HalFile entry = dir.openNextFile(); entry; entry = dir.openNextFile()) {
      name[0] = '\0';
      entry.getName(name, sizeof(name));
      const bool isDir = entry.isDirectory();
      entry.close();
      if (isDir || name[0] == '.' || !isRomName(name)) continue;
      Rom rom;
      rom.path = std::string(dirPath) + "/" + name;
      rom.name = name;
      rom.name.erase(rom.name.find_last_of('.'));
      rom.folder = dirPath;
      roms_.push_back(std::move(rom));
    }
    dir.close();
  }
  std::sort(roms_.begin(), roms_.end(), [](const Rom& a, const Rom& b) { return a.name < b.name; });
  rebuildRows();
}

// Row layout: [controller setup] [ROMs...] (or a hint when there are none). Row text lives in
// labels_/values_, sized once so the pointers kept in items_ stay valid.
void GameBoyRomsActivity::rebuildRows() {
  const size_t total = 1 + roms_.size() + (roms_.empty() ? 1 : 0);
  labels_.assign(total, std::string());
  values_.assign(total, std::string());
  items_.clear();
  items_.reserve(total);

  size_t row = 0;
  labels_[row] = tr(STR_GB_CONTROLLER);
  {
    fui::ListItem item;
    item.label = labels_[row].c_str();
    item.actionValue = static_cast<int16_t>(row);
    items_.push_back(item);
    ++row;
  }
  for (size_t i = 0; i < roms_.size(); ++i, ++row) {
    labels_[row] = roms_[i].name;
    values_[row] = roms_[i].folder;
    fui::ListItem item;
    item.label = labels_[row].c_str();
    item.value = values_[row].c_str();
    item.actionValue = static_cast<int16_t>(row);
    items_.push_back(item);
  }
  if (roms_.empty()) {
    labels_[row] = tr(STR_GB_NO_ROMS);
    fui::ListItem item;
    item.label = labels_[row].c_str();
    item.actionValue = static_cast<int16_t>(row);
    items_.push_back(item);
  }
}

void GameBoyRomsActivity::buildScreen(UiScreen& screen) {
  const auto& metrics = UITheme::getInstance().getMetrics();
  const Rect safe = UITheme::getInstance().getScreenSafeArea(renderer, true, false);
  screen.setContentMarginFromScreen(fui::Insets{
      static_cast<int16_t>(safe.y + metrics.topPadding + metrics.headerHeight),
      static_cast<int16_t>(renderer.getScreenWidth() - (safe.x + safe.width)),
      static_cast<int16_t>(renderer.getScreenHeight() - (safe.y + safe.height)), static_cast<int16_t>(safe.x)});
  screen.spacer(static_cast<int16_t>(metrics.verticalSpacing));

  fui::ListProps props;
  props.items = items_.data();
  props.count = static_cast<uint16_t>(items_.size());
  props.action = ACTION_ROW;
  props.inputMask = fui::InputTouch;  // physical buttons stay in loop()
  props.valueInset = 8;
  props.labelText = screen.theme().smallText;
  props.labelText.maxLines = 2;
  syncListViewport(screen, props);
  screen.list(props);
}

// UiListActivity hands back the row index (the rows' actionValue is that index). Row 0 is the
// controller setup, rows 1..N are roms_[0..N-1]; the "no ROMs" hint row is past the ROMs.
void GameBoyRomsActivity::activateIndex(const int index) {
  if (index < 0 || index >= static_cast<int>(items_.size())) return;
  app.clearTapFlash();
  nav.selected = index;

  if (index == 0) {
    startActivityForResult(std::make_unique<GameBoyPadActivity>(renderer, mappedInput),
                           [this](const ActivityResult&) { requestUpdate(); });
    return;
  }

#if CROSSINK_GAMEBOY
  const size_t ri = static_cast<size_t>(index - 1);
  if (ri >= roms_.size()) return;
  startActivityForResult(std::make_unique<GameBoyActivity>(renderer, mappedInput, roms_[ri].path),
                         [this](const ActivityResult&) {
                           renderer.clearScreen();
                           renderer.displayBuffer(HalDisplay::FULL_REFRESH);
                           requestUpdate();
                         });
#endif
}
