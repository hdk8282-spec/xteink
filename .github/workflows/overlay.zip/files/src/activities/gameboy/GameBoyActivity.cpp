#include "GameBoyActivity.h"

#if CROSSINK_GAMEBOY

#include <Arduino.h>
#include <GfxRenderer.h>
#include <HalDisplay.h>
#include <HalClock.h>
#include <HalGPIO.h>
#include <HalPowerManager.h>
#include <HalStorage.h>
#include <I18n.h>
#include <Logging.h>
#include <esp_heap_caps.h>
#include <esp_timer.h>

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <ctime>

#include "MappedInputManager.h"
#include "fontIds.h"

namespace {

constexpr char TAG[] = "GB";
constexpr size_t ROM_HEADER_SIZE = 0x150;
constexpr size_t PEANUT_ROM_BANK_BYTES = 16384;
constexpr int TOUCH_TARGET_GAP = 8;
constexpr char kSettingsPath[] = "/.crosspoint/gameboy.cfg";

// A saved state: this header, Peanut-GB's whole gb_s (or Walnut-CGB's context) and the cartridge RAM.
struct StateHeader {
  char magic[4];  // "GBQS"
  uint16_t version;
  uint16_t reserved;  // 1 = Walnut-CGB, 0 = Peanut-GB
  uint32_t gbSize;
  uint32_t cartRamSize;
  uint32_t romSize;
  char title[16];
};
constexpr uint16_t kStateVersion = 1;

uint64_t nowMicros() { return static_cast<uint64_t>(esp_timer_get_time()); }

bool hitRect(const int x, const int y, const int rx, const int ry, const int rw, const int rh) {
  return x >= rx && x < rx + rw && y >= ry && y < ry + rh;
}

// Local wall-clock time, from the RTC (or the system clock when that is set).
bool readClock(struct tm& out) {
  struct tm t = {};
  bool ok = false;
  if (halClock.isAvailable() && halClock.localTime(t)) {
    ok = true;
  } else {
    const time_t now = time(nullptr);
    if (now > 1700000000 && localtime_r(&now, &t)) ok = true;
  }
  if (!ok) return false;
  out = t;
  return true;
}

bool isBatteryBackedCartType(const uint8_t type) {
  switch (type) {
    case 0x03: case 0x06: case 0x09: case 0x0D: case 0x0F: case 0x10: case 0x13: case 0x1B: case 0x1E:
    case 0x22: case 0xFF:
      return true;
    default:
      return false;
  }
}

// The picture's greys: 17 levels of darkness, 0 white to 16 black, drawn as an ordered (4x4 Bayer)
// dither. A Game Boy's four shades use 0, 4, 12 and 16 (kDmgLevel); Game Boy Color colours any level.
constexpr int kGreyLevels = 17;
constexpr uint8_t kDmgLevel[4] = {0, 4, 12, 16};
constexpr uint8_t kBayer4[4][4] = {{0, 8, 2, 10}, {12, 4, 14, 6}, {3, 11, 1, 9}, {15, 7, 13, 5}};

bool shadeIsBlack(const uint8_t level, const int x, const int y) { return kBayer4[y & 3][x & 3] < level; }

// One panel row of the game a byte at a time: `count` game pixels read from `src` every `step`
// bytes, each `scale` panel pixels long (1 = black in `patterns`, the framebuffer's 1 is white).
constexpr int MAX_GAME_ROW_BYTES = 64;
void buildGameRow(uint8_t* out, const uint8_t* src, const int step, const int count, const int scale,
                  const uint8_t (&patterns)[kGreyLevels][4]) {
  uint32_t acc = 0;
  int bits = 0;
  for (int g = 0; g < count; ++g) {
    acc = (acc << scale) | patterns[src[g * step]][(g * scale) & 3];
    bits += scale;
    if (bits >= 8) {
      bits -= 8;
      *out++ = static_cast<uint8_t>(~(acc >> bits));
      acc &= (1u << bits) - 1u;
    }
  }
}

// patterns[fixedPhase][level][alongPhase]: the dither for a panel row whose fixed coordinate is
// fixedPhase mod 4. alongIsX says whether the row runs along the dither's x.
void gamePatterns(uint8_t (&patterns)[4][kGreyLevels][4], const int scale, const bool alongIsX) {
  for (int fixed = 0; fixed < 4; ++fixed) {
    for (int shade = 0; shade < kGreyLevels; ++shade) {
      for (int along0 = 0; along0 < 4; ++along0) {
        uint8_t pattern = 0;
        for (int k = 0; k < scale; ++k) {
          const int along = along0 + k;
          const bool black = alongIsX ? shadeIsBlack(static_cast<uint8_t>(shade), along, fixed)
                                      : shadeIsBlack(static_cast<uint8_t>(shade), fixed, along);
          pattern = static_cast<uint8_t>((pattern << 1) | (black ? 1 : 0));
        }
        patterns[fixed][shade][along0] = pattern;
      }
    }
  }
}

}  // namespace

GameBoyActivity::GameBoyActivity(GfxRenderer& rendererIn, MappedInputManager& mappedInputIn, std::string romPathIn)
    : Activity("GameBoy", rendererIn, mappedInputIn), romPath(std::move(romPathIn)) {}

GameBoyActivity::~GameBoyActivity() { cleanup(); }

void GameBoyActivity::addControl(const TouchControl control, const int x, const int y, const int w, const int h,
                                 const char* label) {
  if (controlCount >= MAX_CONTROLS) return;
  controls[controlCount++] = ControlButton{control, x, y, w, h, label};
}

// 480x800: the game fills the width on top (y a multiple of 8 for drawGameFramePortrait()), the
// D-pad and B/A below it as on the handheld, then SELECT and START.
void GameBoyActivity::setLayout() {
  const int screenW = renderer.getScreenWidth();
  const int screenH = renderer.getScreenHeight();
  controlCount = 0;
  gameW = GAMEBOY_WIDTH * SCALE;
  gameH = GAMEBOY_HEIGHT * SCALE;
  gameX = (screenW - gameW) / 2;
  gameY = 40;

  const int padY = gameY + gameH + 24;
  const int pad = 64;
  const int padX = 14;
  addControl(TouchControl::Up, padX + pad, padY, pad, pad, "U");
  addControl(TouchControl::Left, padX, padY + pad, pad, pad, "L");
  addControl(TouchControl::Right, padX + 2 * pad, padY + pad, pad, pad, "R");
  addControl(TouchControl::Down, padX + pad, padY + 2 * pad, pad, pad, "D");
  const int ab = 80;
  addControl(TouchControl::A, screenW - 20 - ab, padY + 24, ab, ab, "A");
  addControl(TouchControl::B, screenW - 36 - 2 * ab, padY + 24 + ab * 3 / 4, ab, ab, "B");

  const int rowH = 56;
  const int rowY = screenH - 12 - rowH;
  const int rowW = (screenW - 8 - TOUCH_TARGET_GAP) / 2;
  addControl(TouchControl::Select, 4, rowY, rowW, rowH, "SELECT");
  addControl(TouchControl::Start, 4 + rowW + TOUCH_TARGET_GAP, rowY, rowW, rowH, "START");
  // The settings button sits in the title strip, away from the game buttons (it holds Exit).
  addControl(TouchControl::Settings, screenW - 132, 2, 128, 36, tr(STR_GB_SETTINGS));
}

void GameBoyActivity::onEnter() {
  Activity::onEnter();
  cleanup();

  exitRequested = false;
  saveDirty = false;
  physicalMask = 0;
  touchMask = 0;
  padMask = 0;
  padHeld = 0;
  chordSinceMs = 0;
  menuOpen.store(false, std::memory_order_release);
  emuPaused.store(false, std::memory_order_release);
  emuIdle.store(true, std::memory_order_release);
  menuSelected = 0;
  loadArmed = false;
  menuMessage[0] = '\0';
  activeTouch = TouchControl::None;
  multiTouchActive = false;
  nextFrameUs = 0;
  framesSinceDraw = DRAW_EVERY;
  nextDisplayUs = 0;
  displayDue.store(true, std::memory_order_release);
  fullRefreshDue.store(true, std::memory_order_release);
  error[0] = '\0';
  title[0] = '\0';

  loadSettings();
  gbpad::load(padTable);
  gbpad::resetService();
  padLink = gbpad::Link::Disabled;

  orientationOnEnter = renderer.getOrientation();
  renderer.setOrientation(GfxRenderer::Portrait);
  setLayout();
  renderer.clearScreen(0xFF);

  if (romPath.empty()) {
    showError("No Game Boy ROM selected");
    return;
  }
  if (!loadRom() || !buildSavePaths() || !initEmulator() || !loadSave()) return;

  // The cartridge's clock starts from the wall clock; the emulator advances it while it runs.
  time_t rawTime = 0;
  time(&rawTime);
  struct tm timeInfo {};
  localtime_r(&rawTime, &timeInfo);
  setCoreRtc(timeInfo);

  char gameTitle[17] = {};
  if (cgb) {
    walnut_cgb_rom_name(cgb, gameTitle);
  } else {
    gb_get_rom_name(gb, gameTitle);
  }
  std::strncpy(title, gameTitle, sizeof(title) - 1);
  if (title[0] == '\0') std::strncpy(title, "GAME BOY", sizeof(title) - 1);

  stateExists = Storage.exists(statePath.c_str());
  initialized.store(true, std::memory_order_release);
  applyJoypad();
  requestUpdate(true);

  const uint64_t nowUs = nowMicros();
  nextFrameUs = nowUs;
  nextDisplayUs = nowUs + DISPLAY_PERIOD_US;
  nextAutosaveUs = nowUs + AUTOSAVE_PERIOD_US;
  nextCleanUs = nowUs + CLEAN_REFRESH_PERIOD_US;
  if (fastPanelWanted && fastPanelSupported()) applyFastPanel(true);
  startEmuTask();
  LOG_INF(TAG, "Started %s (%u bytes, save=%u bytes, core %s)", title, static_cast<unsigned>(romSize),
          static_cast<unsigned>(cartRamSize), cgb ? "Walnut-CGB" : "Peanut-GB");
}

void GameBoyActivity::onExit() {
  stopEmuTask();  // before the save and cleanup touch its state
  {
    // One lock for everything that touches the panel or the SD card: the panel must be idle before the
    // save (shared SPI bus) and before its tuning is switched back.
    RenderLock lock(*this);
#if GB_FAST_PANEL
    if (fastActive) display.waitRefreshComplete();
#endif
    if (initialized.load(std::memory_order_acquire)) {
      if (!saveCartRam()) LOG_ERR(TAG, "Save failed during Game Boy exit: %s", savePath.c_str());
    }
  }
  // No screen update is requested from here on: this activity is going away, the next one draws.
  applyFastPanel(false, /*notify=*/false);
  cleanup();
  renderer.setOrientation(orientationOnEnter);
  Activity::onExit();
}

void GameBoyActivity::loop() {
  handleInput();
  if (exitRequested) {
    finish();
    return;
  }

  if (!initialized.load(std::memory_order_acquire)) {
    int tx = 0, ty = 0;
    if (mappedInput.wasPressed(MappedInputManager::Button::Back) || mappedInput.wasScreenTouchDown(tx, ty)) finish();
    return;
  }

  const uint64_t nowUs = nowMicros();
  if (nowUs >= nextDisplayUs) {
    displayDue.store(true, std::memory_order_release);
    nextDisplayUs = nowUs + DISPLAY_PERIOD_US;
    requestUpdate();
  }
  delay(2);
}

void GameBoyActivity::startEmuTask() {
  emuRun.store(true, std::memory_order_release);
  emuStopped.store(false, std::memory_order_release);
  if (xTaskCreatePinnedToCore(&GameBoyActivity::emuTaskEntry, "GameBoyEmu", 12288, this, 1, &emuTask, 0) != pdPASS) {
    LOG_ERR(TAG, "Could not start the emulator task");
    emuTask = nullptr;
    emuRun.store(false, std::memory_order_release);
    emuStopped.store(true, std::memory_order_release);
    showError("Could not start the emulator");
  }
}

// Asks the emulator task to finish its frame and waits for it (bounded).
void GameBoyActivity::stopEmuTask() {
  if (!emuTask) return;
  emuRun.store(false, std::memory_order_release);
  const unsigned long start = millis();
  while (!emuStopped.load(std::memory_order_acquire) && millis() - start < 1000) delay(1);
  if (!emuStopped.load(std::memory_order_acquire)) LOG_ERR(TAG, "Emulator task did not stop in time");
  emuTask = nullptr;
}

void GameBoyActivity::emuTaskEntry(void* arg) {
  auto* self = static_cast<GameBoyActivity*>(arg);
  self->emuTaskLoop();
  self->emuStopped.store(true, std::memory_order_release);
  vTaskDelete(nullptr);
}

void GameBoyActivity::emuTaskLoop() {
  while (emuRun.load(std::memory_order_acquire)) {
    if (emuPaused.load(std::memory_order_acquire)) {
      emuIdle.store(true, std::memory_order_release);
      delay(5);
      continue;
    }
    emuIdle.store(false, std::memory_order_release);
    const uint64_t nowUs = nowMicros();
    runEmulation(nowUs);

    if (nowUs >= nextCleanUs) {
      nextCleanUs = nowUs + CLEAN_REFRESH_PERIOD_US;
      fullRefreshDue.store(true, std::memory_order_release);
    }
    if (nowUs >= nextAutosaveUs) {
      nextAutosaveUs = nowUs + AUTOSAVE_PERIOD_US;
      if (saveDirty) {
        // The SD card shares the SPI bus with the panel: let a running refresh finish first.
        RenderLock lock(*this);
#if GB_FAST_PANEL
        if (fastActive) display.waitRefreshComplete();
#endif
        if (!saveCartRam()) LOG_ERR(TAG, "Autosave failed: %s", savePath.c_str());
      }
    }
    // Let the idle task (and its watchdog) run between frames.
    delay(1);
  }
  emuIdle.store(true, std::memory_order_release);
}

void GameBoyActivity::runEmulation(const uint64_t nowUs) {
  if ((!gb && !cgb) || nextFrameUs == 0) nextFrameUs = nowUs;

  uint8_t ran = 0;
  while (nowUs >= nextFrameUs && ran < MAX_CATCH_UP_FRAMES) {
    // Draw one frame in DRAW_EVERY. Never draw into a buffer the render task owns, nor over the
    // most recently completed frame before it was consumed: such a frame runs undrawn instead,
    // so the game never waits for the screen.
    bool draw = framesSinceDraw + 1 >= drawEvery();
    if (draw) {
      const uint8_t pending = readyFrame.load(std::memory_order_acquire);
      const uint8_t rendering = renderFrame.load(std::memory_order_acquire);
      if (writeFrame == pending || writeFrame == rendering) draw = false;
    }

    if (cgb) {
      walnut_cgb_set_draw(cgb, draw ? 1 : 0);
      walnut_cgb_run_frame(cgb);
    } else {
      gb->direct.frame_skip = true;
      gb->display.frame_skip_count = draw;
      gb_run_frame(gb);
    }
    if (draw) {
      publishCompletedFrame();
      framesSinceDraw = 0;
    } else if (framesSinceDraw < drawEvery()) {
      ++framesSinceDraw;
    }
    nextFrameUs += EMULATION_FRAME_PERIOD_US;
    ++ran;
  }
  if (ran == MAX_CATCH_UP_FRAMES && nowUs >= nextFrameUs) nextFrameUs = nowUs + EMULATION_FRAME_PERIOD_US;
}

void GameBoyActivity::publishCompletedFrame() {
  readyFrame.store(writeFrame, std::memory_order_release);
  writeFrame ^= 1u;
}

// ---- drawing ---------------------------------------------------------------------------------

void GameBoyActivity::render(RenderLock&&) {
  if (!displayDue.exchange(false, std::memory_order_acq_rel)) return;

  if (!initialized.load(std::memory_order_acquire)) {
    renderer.clearScreen(0xFF);
    renderer.drawCenteredText(UI_12_FONT_ID, renderer.getScreenHeight() / 2 - 32, "GAME BOY", true,
                              EpdFontFamily::BOLD);
    if (error[0]) renderer.drawCenteredText(UI_10_FONT_ID, renderer.getScreenHeight() / 2 + 8, error, true);
    renderer.drawCenteredText(UI_10_FONT_ID, renderer.getScreenHeight() / 2 + 70, "Back / touch to exit", true);
    renderer.displayBuffer(HalDisplay::FAST_REFRESH);
    return;
  }

  // The framebuffer keeps the title and the buttons from the last picture (single-buffered): they
  // are redrawn only with a cleaning refresh.
  if (menuOpen.load(std::memory_order_acquire)) {
    if (!menuDirty.exchange(false, std::memory_order_acq_rel)) return;
    drawMenu();
#if GB_FAST_PANEL
    if (fastActive) display.waitRefreshComplete();
#endif
    renderer.displayBuffer(HalDisplay::FAST_REFRESH);
    return;
  }

  const bool cleaning = fullRefreshDue.exchange(false, std::memory_order_acq_rel);
  // Nothing new to show: skip the refresh. A refresh costs about half a second of panel time, and one
  // spent on an unchanged picture would delay the next real one.
  if (!cleaning && readyFrame.load(std::memory_order_acquire) > 1) return;
  if (cleaning) {
    renderer.clearScreen(0xFF);
    drawChrome();
  }
  drawTopBar();
  drawGameFrame();
  // The picture is in the framebuffer now: hand the Game Boy frame back before the slow e-ink
  // refresh, or the emulator would stand still for the whole refresh.
  releaseRenderedFrame();
#if GB_FAST_PANEL
  if (fastActive) {
    // Tuned fast refresh: the call returns while the waveform runs and the next picture is drawn
    // meanwhile (the driver keeps its own copy of the frame). A cleaning refresh is a blocking one
    // and waits for the running refresh first.
    if (!cleaning && renderer.supportsAsyncRefresh()) {
      renderer.displayBufferAsync(HalDisplay::FAST_REFRESH);
      return;
    }
    display.waitRefreshComplete();
  }
#endif
  renderer.displayBuffer(cleaning ? HalDisplay::HALF_REFRESH : HalDisplay::FAST_REFRESH);
}

void GameBoyActivity::drawChrome() {
  for (size_t i = 0; i < controlCount; ++i) {
    const ControlButton& c = controls[i];
    renderer.drawRoundedRect(c.x, c.y, c.w, c.h, 2, 10, true);
    const int textW = renderer.getTextWidth(UI_10_FONT_ID, c.label);
    const int textH = renderer.getLineHeight(UI_10_FONT_ID);
    renderer.drawText(UI_10_FONT_ID, c.x + (c.w - textW) / 2, c.y + (c.h - textH) / 2, c.label, true);
  }
}

void GameBoyActivity::drawGameFrame() {
  const uint8_t frameIndex = readyFrame.load(std::memory_order_acquire);
  if (frameIndex > 1) return;

  const uint8_t* source = frameBuffers[frameIndex];
  uint8_t* framebuffer = renderer.getFrameBuffer();
  if (!source || !framebuffer) return;

  // Claim the exact source buffer before reading it; the emulator task checks this marker.
  renderFrame.store(frameIndex, std::memory_order_release);
  if (!drawGameFramePortrait(source, framebuffer)) renderFrame.store(0xFF, std::memory_order_release);
}

void GameBoyActivity::releaseRenderedFrame() {
  const uint8_t claimedFrame = renderFrame.load(std::memory_order_acquire);
  if (claimedFrame > 1) return;
  uint8_t expected = claimedFrame;
  readyFrame.compare_exchange_strong(expected, static_cast<uint8_t>(0xFF), std::memory_order_acq_rel,
                                     std::memory_order_acquire);
  renderFrame.store(0xFF, std::memory_order_release);
}

// Portrait turns the panel a quarter: logical (x, y) is panel (y, panelHeight - 1 - x). Each game
// column is one panel row with the game's lines running along it. A column's panel rows differ
// only by their x phase in the 4x4 dither: four are built, the rest copied.
bool GameBoyActivity::drawGameFramePortrait(const uint8_t* source, uint8_t* framebuffer) {
  const int panelBytes = renderer.getDisplayWidthBytes();
  const int panelW = renderer.getDisplayWidth();
  const int panelH = renderer.getDisplayHeight();
  const int rowBytes = gameH / 8;
  const int startY = gameY;
  if (panelBytes <= 0 || startY < 0 || startY % 8 != 0 || gameH % 8 != 0 || gameX < 0 || gameX + gameW > panelH ||
      gameY + gameH > panelW || rowBytes > MAX_GAME_ROW_BYTES) {
    return false;
  }
  uint8_t patterns[4][kGreyLevels][4];
  gamePatterns(patterns, SCALE, /*alongIsX=*/false);
  uint8_t rows[4][MAX_GAME_ROW_BYTES];
  for (int gx = 0; gx < GAMEBOY_WIDTH; ++gx) {
    for (int parity = 0; parity < 4; ++parity) {
      buildGameRow(rows[parity], source + gx, GAMEBOY_WIDTH, GAMEBOY_HEIGHT, SCALE, patterns[parity]);
    }
    for (int sx = 0; sx < SCALE; ++sx) {
      const int dstX = gx * SCALE + sx;
      const int row = panelH - 1 - (gameX + dstX);
      std::memcpy(framebuffer + static_cast<size_t>(row) * panelBytes + startY / 8, rows[dstX & 3],
                  static_cast<size_t>(rowBytes));
    }
  }
  return true;
}

// ---- input -----------------------------------------------------------------------------------

void GameBoyActivity::handleInput() {
  using Button = MappedInputManager::Button;
  if (menuOpen.load(std::memory_order_acquire)) {
    handleMenuInput();
    return;
  }

  // Front buttons: D-pad, Confirm = A, Back = B, page keys = Start / Select.
  uint8_t nextPhysical = 0;
  if (mappedInput.isPressed(Button::Up)) nextPhysical |= 0x40;
  if (mappedInput.isPressed(Button::Down)) nextPhysical |= 0x80;
  if (mappedInput.isPressed(Button::Left)) nextPhysical |= 0x20;
  if (mappedInput.isPressed(Button::Right)) nextPhysical |= 0x10;
  if (mappedInput.isPressed(Button::Confirm)) nextPhysical |= 0x01;
  if (mappedInput.isPressed(Button::Back)) nextPhysical |= 0x02;
  if (mappedInput.isPressed(Button::PageForward)) nextPhysical |= 0x08;
  if (mappedInput.isPressed(Button::PageBack)) nextPhysical |= 0x04;
  if (nextPhysical != physicalMask) {
    physicalMask = nextPhysical;
    applyJoypad();
  }

  // Bluetooth controller.
  padLink = gbpad::service();
  if (gbpad::poll(padTable, padHeld)) {
    uint8_t mask = 0;
    for (uint8_t i = 0; i < gbpad::ControlCount; ++i) {
      if (padHeld & (1u << i)) mask |= gbpad::joypadBit(static_cast<gbpad::Control>(i));
    }
    padMask = mask;
    applyJoypad();
  }

  handleTouch();

  // Select + Start held together (from any source) leaves the game.
  const uint8_t all = static_cast<uint8_t>(physicalMask | touchMask | padMask);
  if ((all & 0x04) && (all & 0x08)) {
    if (chordSinceMs == 0) chordSinceMs = millis();
    if (millis() - chordSinceMs >= EXIT_CHORD_MS) exitRequested = true;
  } else {
    chordSinceMs = 0;
  }
}

// Touch. Several fingers can hold several buttons at once (run with B while walking, A + B, ...):
// when the panel reports two or more contacts every contact is hit-tested and the buttons are OR-ed.
// With one finger (or on a build whose touch decoder has no multi-contact snapshot) the usual
// single-touch path runs.
void GameBoyActivity::handleTouch() {
  HalGPIO::TouchPoints points;
  if (gpio.getTouchPoints(points) && points.count >= 2) {
    multiTouchActive = true;
    // Swallow the one-finger "down" edge too, so it cannot replay when a finger lifts.
    int ignoredX = 0, ignoredY = 0;
    (void)mappedInput.wasScreenTouchDown(ignoredX, ignoredY);

    uint8_t nextTouch = 0;
    TouchControl primary = TouchControl::None;
    for (uint8_t i = 0; i < points.count; ++i) {
      int x = 0, y = 0;
      renderer.tapToLogical(points.nx[i], points.ny[i], x, y);
      const TouchControl control = hitTestTouch(x, y);
      if (control == TouchControl::Settings) {
        openMenu();
        return;
      }
      nextTouch |= joypadBitForTouch(control);
      if (primary == TouchControl::None) primary = control;
    }
    if (nextTouch != touchMask || primary != activeTouch) {
      activeTouch = primary;
      touchMask = nextTouch;
      applyJoypad();
    }
    return;
  }
  if (multiTouchActive) {
    // Back to one finger (or none): the held finger rebuilds the mask below.
    multiTouchActive = false;
    activeTouch = TouchControl::None;
    touchMask = 0;
    applyJoypad();
  }

  int x = 0, y = 0;
  if (mappedInput.wasScreenTouchDown(x, y)) updateTouch(x, y);
  if (mappedInput.isScreenTouchHeld(x, y)) {
    updateTouch(x, y);
  } else if (mappedInput.wasScreenTouchReleased()) {
    activeTouch = TouchControl::None;
    touchMask = 0;
    applyJoypad();
  }
}

void GameBoyActivity::updateTouch(const int x, const int y) {
  const TouchControl control = hitTestTouch(x, y);
  if (control == TouchControl::Settings) {
    openMenu();
    return;
  }
  if (control == activeTouch) return;
  activeTouch = control;
  touchMask = joypadBitForTouch(control);
  applyJoypad();
}

GameBoyActivity::TouchControl GameBoyActivity::hitTestTouch(const int x, const int y) const {
  for (size_t i = 0; i < controlCount; ++i) {
    const ControlButton& c = controls[i];
    if (hitRect(x, y, c.x, c.y, c.w, c.h)) return c.control;
  }
  return TouchControl::None;
}

// ---- settings, top bar, fast panel -----------------------------------------------------------

void GameBoyActivity::loadSettings() {
  topBarClock = true;
  fastPanelWanted = false;
  HalFile file;
  if (!Storage.openFileForRead(TAG, kSettingsPath, file)) return;
  char text[128];
  const int got = file.read(text, sizeof(text) - 1);
  file.close();
  if (got <= 0) return;
  text[got] = '\0';
  char* save = nullptr;
  for (char* line = strtok_r(text, "\r\n", &save); line; line = strtok_r(nullptr, "\r\n", &save)) {
    if (std::strcmp(line, "bar=title") == 0) topBarClock = false;
    if (std::strcmp(line, "bar=clock") == 0) topBarClock = true;
    if (std::strcmp(line, "fast=1") == 0) fastPanelWanted = true;
    if (std::strcmp(line, "fast=0") == 0) fastPanelWanted = false;
  }
}

void GameBoyActivity::saveSettings() {
  char text[64];
  const int len = snprintf(text, sizeof(text), "bar=%s\nfast=%d\n", topBarClock ? "clock" : "title",
                           fastPanelWanted ? 1 : 0);
  HalFile file;
  if (len <= 0 || !Storage.openFileForWrite(TAG, kSettingsPath, file)) {
    LOG_ERR(TAG, "Could not save %s", kSettingsPath);
    return;
  }
  file.write(reinterpret_cast<const uint8_t*>(text), static_cast<size_t>(len));
  file.close();
}

// The strip above the picture (the settings button sits at its right end): the clock and the battery,
// or the game's name. Cleared and redrawn with every picture; the panel only sends what changed.
void GameBoyActivity::drawTopBar() {
  const int w = renderer.getScreenWidth();
  renderer.fillRect(0, 0, w - 136, 40, false);
  char text[56];
  if (topBarClock) {
    struct tm t = {};
    char clock[12] = "--:--";
    if (readClock(t)) snprintf(clock, sizeof(clock), "%02d:%02d", t.tm_hour, t.tm_min);
    snprintf(text, sizeof(text), "%s   %u%%", clock, static_cast<unsigned>(powerManager.getBatteryPercentage()));
  } else {
    snprintf(text, sizeof(text), "%s", title);
  }
  if (padLink == gbpad::Link::Connected) {
    const size_t n = std::strlen(text);
    snprintf(text + n, sizeof(text) - n, "   BT");
  }
  renderer.drawText(UI_10_FONT_ID, 8, 10, text, true);
}

// The tuned fast refresh is only for the panel the pokemon fork measured it on: a UC8279 whose variant
// byte is 0x68. Anywhere else it stays off (stock refreshes).
bool GameBoyActivity::fastPanelSupported() const {
#if GB_FAST_PANEL
  // UC8279 variant 0x68: the pokemon fork's tuning (PLL, scaled DU waveform, changed rectangle).
  // SSD1677 (X4 Pro): the driver's game mode (incremental DU refresh + changed rectangle only).
  return (BoardConfig::ACTIVE.displayController == BoardConfig::DisplayController::UC8279 &&
          BoardConfig::ACTIVE.displayControllerVariant == 0x68) ||
         BoardConfig::ACTIVE.displayController == BoardConfig::DisplayController::SSD1677;
#else
  return false;
#endif
}

void GameBoyActivity::applyFastPanel(const bool on, const bool notify) {
#if GB_FAST_PANEL
  if (on == fastActive) return;
  {
    RenderLock lock(*this);
    display.waitRefreshComplete();  // no refresh may run while these change
    if (on) {
      display.setFastRefreshTuning(0, 0x0F);  // forced frame rate (PLL), stock temperature
      display.setFastRefreshDuScale(40);      // the DU waveform at 40% of its frames
      display.setFastRefreshDiffWindow(true);  // only the changed rectangle is sent and driven
      display.setDisplaySpiHz(20000000);       // the controller's rating
    } else {
      display.setFastRefreshTuning(0, 0);
      display.setFastRefreshDuScale(0);
      display.setFastRefreshDiffWindow(false);
      display.setDisplaySpiHz(0);
    }
    fastActive = on;
  }
  if (!notify) return;  // leaving the game: nothing may ask this activity to draw any more
  nextCleanUs = nowMicros() + (on ? 60000000ULL : CLEAN_REFRESH_PERIOD_US);
  fullRefreshDue.store(true, std::memory_order_release);
  displayDue.store(true, std::memory_order_release);
  requestUpdate();
#else
  (void)on;
  (void)notify;
#endif
}

// ---- in-game menu ----------------------------------------------------------------------------

int GameBoyActivity::menuRowTop() const { return 120; }
int GameBoyActivity::menuRowHeight() const { return 80; }

void GameBoyActivity::menuLabel(const int index, char* out, const size_t outSize) const {
#if GB_FAST_PANEL
  if (static_cast<MenuItem>(index) == MenuItem::FastPanel && !fastPanelSupported()) {
    // Say which panel this reader has, so a mismatch can be told apart.
    const auto controller = BoardConfig::ACTIVE.displayController;
    const char* name = controller == BoardConfig::DisplayController::UC8279   ? "UC8279"
                       : controller == BoardConfig::DisplayController::UC8179 ? "UC8179"
                                                                                : "SSD1677";
    snprintf(out, outSize, "%s (%s 0x%02X)", tr(STR_GB_FAST_UNSUPPORTED), name,
             static_cast<unsigned>(BoardConfig::ACTIVE.displayControllerVariant));
    return;
  }
#endif
  const char* text = "";
  switch (static_cast<MenuItem>(index)) {
    case MenuItem::Resume: text = tr(STR_GB_MENU_RESUME); break;
    case MenuItem::SaveState: text = tr(STR_GB_STATE_SAVE); break;
    case MenuItem::LoadState: text = tr(STR_GB_STATE_LOAD); break;
    case MenuItem::WriteSave: text = tr(STR_GB_SAVE_FILE); break;
    case MenuItem::TopBar: text = topBarClock ? tr(STR_GB_BAR_CLOCK) : tr(STR_GB_BAR_TITLE); break;
    case MenuItem::FastPanel:
#if GB_FAST_PANEL
      text = !fastPanelSupported() ? tr(STR_GB_FAST_UNSUPPORTED) : (fastPanelWanted ? tr(STR_GB_FAST_ON) : tr(STR_GB_FAST_OFF));
#else
      text = tr(STR_GB_FAST_NA);
#endif
      break;
    case MenuItem::Exit: text = tr(STR_GB_EXIT); break;
    default: break;
  }
  snprintf(out, outSize, "%s", text);
}

bool GameBoyActivity::waitEmuIdle() {
  const unsigned long start = millis();
  while (!emuIdle.load(std::memory_order_acquire)) {
    if (millis() - start > 500) return false;
    delay(2);
  }
  return true;
}

void GameBoyActivity::openMenu() {
  physicalMask = 0;
  touchMask = 0;
  padMask = 0;
  padHeld = 0;
  activeTouch = TouchControl::None;
  multiTouchActive = false;
  applyJoypad();
  emuPaused.store(true, std::memory_order_release);
  stateExists = Storage.exists(statePath.c_str());
  menuSelected = 0;
  loadArmed = false;
  menuMessage[0] = '\0';
  menuOpen.store(true, std::memory_order_release);
  menuDirty.store(true, std::memory_order_release);
  requestUpdate();
}

void GameBoyActivity::closeMenu() {
  menuOpen.store(false, std::memory_order_release);
  loadArmed = false;
  const uint64_t nowUs = nowMicros();
  nextFrameUs = 0;  // no catch-up burst for the time spent in the menu
  nextDisplayUs = nowUs + DISPLAY_PERIOD_US;
  nextAutosaveUs = nowUs + AUTOSAVE_PERIOD_US;
  nextCleanUs = nowUs + CLEAN_REFRESH_PERIOD_US;
  readyFrame.store(0xFF, std::memory_order_release);
  fullRefreshDue.store(true, std::memory_order_release);
  displayDue.store(true, std::memory_order_release);
  emuPaused.store(false, std::memory_order_release);
  requestUpdate();
}

void GameBoyActivity::handleMenuInput() {
  using Button = MappedInputManager::Button;
  const int count = static_cast<int>(MenuItem::Count);
  if (mappedInput.wasPressed(Button::Up)) {
    menuSelected = static_cast<uint8_t>((menuSelected + count - 1) % count);
    menuDirty.store(true, std::memory_order_release);
    requestUpdate();
  } else if (mappedInput.wasPressed(Button::Down)) {
    menuSelected = static_cast<uint8_t>((menuSelected + 1) % count);
    menuDirty.store(true, std::memory_order_release);
    requestUpdate();
  } else if (mappedInput.wasPressed(Button::Confirm)) {
    menuActivate(static_cast<MenuItem>(menuSelected));
  } else if (mappedInput.wasPressed(Button::Back)) {
    closeMenu();
  }

  int x = 0, y = 0;
  if (mappedInput.wasScreenTouchDown(x, y)) {
    const int top = menuRowTop();
    const int rowH = menuRowHeight();
    if (y >= top && y < top + count * rowH) {
      menuSelected = static_cast<uint8_t>((y - top) / rowH);
      menuActivate(static_cast<MenuItem>(menuSelected));
    }
  }
}

void GameBoyActivity::menuActivate(const MenuItem item) {
  if (item != MenuItem::LoadState) loadArmed = false;
  menuMessage[0] = '\0';
  const auto say = [this](const char* text) {
    std::strncpy(menuMessage, text, sizeof(menuMessage) - 1);
    menuMessage[sizeof(menuMessage) - 1] = '\0';
  };
  switch (item) {
    case MenuItem::Resume:
      closeMenu();
      return;
    case MenuItem::SaveState: {
      bool ok = false;
      if (waitEmuIdle()) {
        RenderLock lock(*this);
#if GB_FAST_PANEL
        if (fastActive) display.waitRefreshComplete();
#endif
        ok = writeState(statePath);
      }
      stateExists = stateExists || ok;
      say(ok ? tr(STR_GB_SAVED) : tr(STR_GB_SAVE_FAILED));
      break;
    }
    case MenuItem::LoadState:
      if (!stateExists) {
        say(tr(STR_GB_NO_STATE));
      } else if (!loadArmed) {
        // Loading throws away the play since the save: asked twice.
        loadArmed = true;
        say(tr(STR_GB_LOAD_AGAIN));
      } else if (waitEmuIdle() && [this] {
                   RenderLock lock(*this);
#if GB_FAST_PANEL
                   if (fastActive) display.waitRefreshComplete();
#endif
                   return readState(statePath);
                 }()) {
        // A real cartridge clock does not go back with the game.
        time_t rawTime = 0;
        time(&rawTime);
        struct tm timeInfo {};
        localtime_r(&rawTime, &timeInfo);
        setCoreRtc(timeInfo);
        closeMenu();
        return;
      } else {
        loadArmed = false;
        say(tr(STR_GB_LOAD_FAILED));
      }
      break;
    case MenuItem::WriteSave: {
      saveDirty = true;
      bool ok = false;
      if (waitEmuIdle()) {
        RenderLock lock(*this);
#if GB_FAST_PANEL
        if (fastActive) display.waitRefreshComplete();
#endif
        ok = saveCartRam();
      }
      say(ok ? tr(STR_GB_SAVED) : tr(STR_GB_SAVE_FAILED));
      break;
    }
    case MenuItem::TopBar:
      topBarClock = !topBarClock;
      saveSettings();
      break;
    case MenuItem::FastPanel:
      if (fastPanelSupported()) {
        fastPanelWanted = !fastPanelWanted;
        saveSettings();
        applyFastPanel(fastPanelWanted);
      }
      break;
    case MenuItem::Exit:
      exitRequested = true;  // onExit() writes the save
      return;
    default:
      break;
  }
  menuDirty.store(true, std::memory_order_release);
  requestUpdate();
}

void GameBoyActivity::drawMenu() {
  const int w = renderer.getScreenWidth();
  const int top = menuRowTop();
  const int rowH = menuRowHeight();
  renderer.clearScreen(0xFF);
  renderer.drawCenteredText(UI_12_FONT_ID, 28, title, true, EpdFontFamily::BOLD);
  renderer.drawCenteredText(UI_10_FONT_ID, 72, tr(STR_GB_SETTINGS), true);

  const int count = static_cast<int>(MenuItem::Count);
  for (int i = 0; i < count; ++i) {
    const int y = top + i * rowH;
    renderer.drawRoundedRect(24, y, w - 48, rowH - 16, i == menuSelected ? 4 : 1, 14, true);
    char label[64];
    menuLabel(i, label, sizeof(label));
    const int textW = renderer.getTextWidth(UI_12_FONT_ID, label);
    const int textH = renderer.getLineHeight(UI_12_FONT_ID);
    renderer.drawText(UI_12_FONT_ID, (w - textW) / 2, y + (rowH - 16 - textH) / 2, label, true);
  }
  if (menuMessage[0]) {
    const auto lines = renderer.wrappedText(UI_10_FONT_ID, menuMessage, w - 64, 3);
    int y = top + count * rowH + 8;
    for (const auto& line : lines) {
      renderer.drawCenteredText(UI_10_FONT_ID, y, line.c_str(), true);
      y += renderer.getLineHeight(UI_10_FONT_ID) + 2;
    }
  }
}

// Writes header + core state + cartridge RAM to `path` (through a .tmp file, so a failed write keeps
// the old one). The emulator must be standing still.
bool GameBoyActivity::writeState(const std::string& path) {
  if (!gb && !cgb) return false;
  const size_t coreSize = cgb ? walnut_cgb_state_size() : sizeof(gb_s);
  StateHeader header{};
  std::memcpy(header.magic, "GBQS", 4);
  header.version = kStateVersion;
  header.reserved = cgb ? 1 : 0;
  header.gbSize = static_cast<uint32_t>(coreSize);
  header.cartRamSize = static_cast<uint32_t>(cartRamSize);
  header.romSize = static_cast<uint32_t>(romSize);
  std::memcpy(header.title, title, sizeof(header.title));

  // Walnut-CGB's context is opaque: copied out first.
  uint8_t* coreState = reinterpret_cast<uint8_t*>(gb);
  if (cgb) {
    coreState = static_cast<uint8_t*>(heap_caps_malloc(coreSize, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!coreState) return false;
    walnut_cgb_save_state(cgb, coreState);
  }
  const std::string tempPath = path + ".tmp";
  HalFile file;
  bool ok = Storage.openFileForWrite(TAG, tempPath, file);
  ok = ok && file.write(reinterpret_cast<const uint8_t*>(&header), sizeof(header)) == sizeof(header) &&
       file.write(coreState, coreSize) == coreSize;
  if (cgb) heap_caps_free(coreState);
  if (ok && cartRamSize > 0) ok = file.write(cartRam, cartRamSize) == cartRamSize;
  file.flush();
  file.close();
  if (ok) {
    if (Storage.exists(path.c_str())) Storage.remove(path.c_str());
    ok = Storage.rename(tempPath.c_str(), path.c_str());
  }
  if (!ok) Storage.remove(tempPath.c_str());
  LOG_INF(TAG, "State %s: %s", ok ? "saved" : "NOT saved", path.c_str());
  return ok;
}

// Loads a state written by writeState() for this ROM, keeping this session's callbacks. The
// emulator must be standing still. The cartridge RAM it brings back is written to the .sav later.
bool GameBoyActivity::readState(const std::string& path) {
  if (!gb && !cgb) return false;
  const size_t coreSize = cgb ? walnut_cgb_state_size() : sizeof(gb_s);
  HalFile file;
  if (!Storage.openFileForRead(TAG, path, file)) return false;
  StateHeader header{};
  bool ok = file.read(reinterpret_cast<uint8_t*>(&header), sizeof(header)) == static_cast<int>(sizeof(header)) &&
            std::memcmp(header.magic, "GBQS", 4) == 0 && header.version == kStateVersion &&
            header.reserved == (cgb ? 1 : 0) && header.gbSize == coreSize && header.cartRamSize == cartRamSize &&
            header.romSize == romSize;
  // Read everything aside first, so a short file leaves the game untouched.
  auto* loaded = static_cast<gb_s*>(heap_caps_malloc(coreSize, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  uint8_t* loadedRam =
      cartRamSize > 0 ? static_cast<uint8_t*>(heap_caps_malloc(cartRamSize, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT))
                      : nullptr;
  ok = ok && loaded && (cartRamSize == 0 || loadedRam) &&
       file.read(reinterpret_cast<uint8_t*>(loaded), coreSize) == static_cast<int>(coreSize) &&
       (cartRamSize == 0 || file.read(loadedRam, cartRamSize) == static_cast<int>(cartRamSize));
  file.close();
  if (ok && cgb) {
    walnut_cgb_load_state(cgb, loaded);
    if (cartRamSize > 0) std::memcpy(cartRam, loadedRam, cartRamSize);
    saveDirty = cartRamSize > 0;
  } else if (ok) {
    // Peanut-GB's only pointers: the callbacks and the front end's context.
    loaded->gb_rom_read = gb->gb_rom_read;
    loaded->gb_cart_ram_read = gb->gb_cart_ram_read;
    loaded->gb_cart_ram_write = gb->gb_cart_ram_write;
    loaded->gb_error = gb->gb_error;
    loaded->gb_serial_tx = gb->gb_serial_tx;
    loaded->gb_serial_rx = gb->gb_serial_rx;
    loaded->gb_bootrom_read = gb->gb_bootrom_read;
    loaded->display.lcd_draw_line = gb->display.lcd_draw_line;
    loaded->direct.priv = gb->direct.priv;
    std::memcpy(gb, loaded, sizeof(gb_s));
    if (cartRamSize > 0) std::memcpy(cartRam, loadedRam, cartRamSize);
    saveDirty = cartRamSize > 0;
  }
  if (loaded) heap_caps_free(loaded);
  if (loadedRam) heap_caps_free(loadedRam);
  LOG_INF(TAG, "State %s: %s", ok ? "loaded" : "NOT loaded", path.c_str());
  return ok;
}

uint8_t GameBoyActivity::joypadBitForTouch(const TouchControl control) {
  switch (control) {
    case TouchControl::Up: return 0x40;
    case TouchControl::Down: return 0x80;
    case TouchControl::Left: return 0x20;
    case TouchControl::Right: return 0x10;
    case TouchControl::A: return 0x01;
    case TouchControl::B: return 0x02;
    case TouchControl::Select: return 0x04;
    case TouchControl::Start: return 0x08;
    default: return 0;
  }
}

void GameBoyActivity::applyJoypad() {
  const uint8_t joypad = static_cast<uint8_t>(~(physicalMask | touchMask | padMask));
  if (gb) gb->direct.joypad = joypad;
  if (cgb) walnut_cgb_set_joypad(cgb, joypad);
}

// ---- ROM, emulator and saves -----------------------------------------------------------------

bool GameBoyActivity::loadRom() {
  HalFile file;
  if (!Storage.openFileForRead(TAG, romPath, file)) {
    showError("Unable to open Game Boy ROM");
    return false;
  }
  const uint64_t fileSize = file.fileSize64();
  if (fileSize < ROM_HEADER_SIZE || fileSize > static_cast<uint64_t>(SIZE_MAX)) {
    file.close();
    showError("ROM size is invalid");
    return false;
  }
  uint8_t romSizeCode = 0xFF;
  if (!file.seekSet(0x148) || file.read(&romSizeCode, 1) != 1) {
    file.close();
    showError("ROM header could not be read");
    return false;
  }
  // Peanut-GB's ROM-size table covers codes 0..8.
  if (romSizeCode > 8) {
    file.close();
    showError("Unsupported ROM size");
    return false;
  }
  const size_t expectedSize = (static_cast<size_t>(2) << romSizeCode) * PEANUT_ROM_BANK_BYTES;
  if (fileSize < expectedSize) {
    file.close();
    showError("ROM file is incomplete");
    return false;
  }
  rom = static_cast<uint8_t*>(heap_caps_malloc(expectedSize, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!rom) {
    file.close();
    showError("Not enough PSRAM for ROM");
    return false;
  }
  if (!file.seekSet(0)) {
    file.close();
    showError("ROM seek failed");
    return false;
  }
  size_t offset = 0;
  while (offset < expectedSize) {
    const size_t chunk = std::min<size_t>(16384, expectedSize - offset);
    const int got = file.read(rom + offset, chunk);
    if (got <= 0) {
      file.close();
      showError("ROM read failed");
      return false;
    }
    offset += static_cast<size_t>(got);
  }
  file.close();
  romSize = expectedSize;
  if (rom[0x149] > 5) {
    showError("Unsupported cartridge RAM");
    return false;
  }
  return true;
}

bool GameBoyActivity::buildSavePaths() {
  savePath = romPath;
  const size_t slash = savePath.find_last_of('/');
  const size_t dot = savePath.find_last_of('.');
  if (dot == std::string::npos || (slash != std::string::npos && dot < slash)) {
    savePath += ".sav";
  } else {
    savePath.replace(dot, std::string::npos, ".sav");
  }
  statePath = savePath.substr(0, savePath.size() - 4) + ".state";
  tempSavePath = savePath + ".tmp";
  backupSavePath = savePath + ".bak";
  return savePath.size() < 512;
}

bool GameBoyActivity::initEmulator() {
  size_t saveSize = 0;
  if (rom[0x143] & 0x80) {
    // Made for (or also for) the Game Boy Color: the Walnut-CGB core.
    int initResult = 0;
    cgb = walnut_cgb_create(rom, romSize, &GameBoyActivity::cgbLine, &GameBoyActivity::cgbError, this, &initResult);
    if (!cgb) {
      showError(initResult < 0 ? "Not enough memory for emulator" : initErrorString(initResult));
      return false;
    }
    walnut_cgb_set_ram_written(cgb, &GameBoyActivity::cgbRamWritten);
    walnut_cgb_set_colours(cgb, WALNUT_COLOURS_CONTRAST);
    if (walnut_cgb_save_size(cgb, &saveSize) < 0) {
      showError("Unknown cartridge RAM size");
      return false;
    }
  } else {
    gb = static_cast<gb_s*>(calloc(1, sizeof(gb_s)));
    if (!gb) {
      showError("Not enough memory for emulator");
      return false;
    }
    const enum gb_init_error_e initResult =
        gb_init(gb, &GameBoyActivity::romRead, &GameBoyActivity::cartRamRead, &GameBoyActivity::cartRamWrite,
                &GameBoyActivity::fatalError, this);
    if (initResult != GB_INIT_NO_ERROR) {
      showError(initErrorString(initResult));
      return false;
    }
    if (gb_get_save_size_s(gb, &saveSize) < 0) {
      showError("Unknown cartridge RAM size");
      return false;
    }
  }

  if (saveSize > 0) {
    cartRam = static_cast<uint8_t*>(heap_caps_malloc(saveSize, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!cartRam) {
      showError("Not enough PSRAM for save RAM");
      return false;
    }
    std::memset(cartRam, 0, saveSize);
    cartRamSize = saveSize;
    if (cgb) walnut_cgb_set_cart_ram(cgb, cartRam, cartRamSize);
  }

  frameBuffers[0] = static_cast<uint8_t*>(heap_caps_malloc(EMULATOR_FRAME_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  frameBuffers[1] = static_cast<uint8_t*>(heap_caps_malloc(EMULATOR_FRAME_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!frameBuffers[0] || !frameBuffers[1]) {
    showError("Not enough PSRAM for Game Boy video");
    return false;
  }
  std::memset(frameBuffers[0], 0, EMULATOR_FRAME_BYTES);  // white
  std::memset(frameBuffers[1], 0, EMULATOR_FRAME_BYTES);
  writeFrame = 0;
  readyFrame.store(0xFF, std::memory_order_release);
  renderFrame.store(0xFF, std::memory_order_release);

  if (gb) gb_init_lcd(gb, &GameBoyActivity::lcdDrawLine);
  return true;
}

bool GameBoyActivity::loadSave() {
  if (cartRamSize == 0 || !isBatteryBackedCartType(rom[0x147])) return true;
  std::memset(cartRam, 0, cartRamSize);
  HalFile file;
  if (!Storage.openFileForRead(TAG, savePath, file)) return true;  // New save; the normal case.
  size_t offset = 0;
  while (offset < cartRamSize) {
    const int got = file.read(cartRam + offset, cartRamSize - offset);
    if (got <= 0) break;
    offset += static_cast<size_t>(got);
  }
  file.close();
  LOG_INF(TAG, "Loaded save: %u/%u bytes", static_cast<unsigned>(offset), static_cast<unsigned>(cartRamSize));
  return true;
}

// Written to a temp file, then renamed over the old save (kept as .bak while the swap runs).
bool GameBoyActivity::saveCartRam() {
  if (!saveDirty || cartRamSize == 0 || !cartRam || !rom || !isBatteryBackedCartType(rom[0x147])) return true;

  HalFile file;
  if (!Storage.openFileForWrite(TAG, tempSavePath, file)) {
    LOG_ERR(TAG, "Unable to open save temp file: %s", tempSavePath.c_str());
    return false;
  }
  const size_t written = file.write(cartRam, cartRamSize);
  file.flush();
  file.close();
  if (written != cartRamSize) {
    Storage.remove(tempSavePath.c_str());
    LOG_ERR(TAG, "Save write failed: wrote=%u expected=%u", static_cast<unsigned>(written),
            static_cast<unsigned>(cartRamSize));
    return false;
  }

  const bool hadExisting = Storage.exists(savePath.c_str());
  if (hadExisting) {
    Storage.remove(backupSavePath.c_str());
    if (!Storage.rename(savePath.c_str(), backupSavePath.c_str())) {
      Storage.remove(tempSavePath.c_str());
      LOG_ERR(TAG, "Could not stage previous save before commit");
      return false;
    }
  }
  if (!Storage.rename(tempSavePath.c_str(), savePath.c_str())) {
    if (hadExisting) Storage.rename(backupSavePath.c_str(), savePath.c_str());
    Storage.remove(tempSavePath.c_str());
    LOG_ERR(TAG, "Could not commit save: %s", savePath.c_str());
    return false;
  }
  if (hadExisting) Storage.remove(backupSavePath.c_str());
  saveDirty = false;
  LOG_INF(TAG, "Saved: %s", savePath.c_str());
  return true;
}

void GameBoyActivity::cleanup() {
  initialized.store(false, std::memory_order_release);
  if (gb) {
    free(gb);
    gb = nullptr;
  }
  if (cgb) {
    walnut_cgb_destroy(cgb);
    cgb = nullptr;
  }
  if (rom) {
    heap_caps_free(rom);
    rom = nullptr;
  }
  if (cartRam) {
    heap_caps_free(cartRam);
    cartRam = nullptr;
  }
  for (auto*& buffer : frameBuffers) {
    if (buffer) heap_caps_free(buffer);
    buffer = nullptr;
  }
  writeFrame = 0;
  readyFrame.store(0xFF, std::memory_order_release);
  renderFrame.store(0xFF, std::memory_order_release);
  romSize = 0;
  cartRamSize = 0;
  physicalMask = 0;
  touchMask = 0;
  padMask = 0;
  padHeld = 0;
  activeTouch = TouchControl::None;
  saveDirty = false;
}

void GameBoyActivity::showError(const char* message) {
  std::strncpy(error, message ? message : "Game Boy error", sizeof(error) - 1);
  error[sizeof(error) - 1] = '\0';
  initialized.store(false, std::memory_order_release);
  displayDue.store(true, std::memory_order_release);
  requestUpdate();
}

void GameBoyActivity::setCoreRtc(const struct tm& time) {
  if (cgb) {
    walnut_cgb_set_rtc(cgb, &time);
  } else if (gb) {
    gb_set_rtc(gb, &time);
  }
}

// ---- core callbacks --------------------------------------------------------------------------

uint8_t GameBoyActivity::romRead(gb_s* state, const uint_fast32_t addr) {
  auto* self = state ? static_cast<GameBoyActivity*>(state->direct.priv) : nullptr;
  if (!self || !self->rom || addr >= self->romSize) return 0xFF;
  return self->rom[addr];
}

uint8_t GameBoyActivity::cartRamRead(gb_s* state, const uint_fast32_t addr) {
  auto* self = state ? static_cast<GameBoyActivity*>(state->direct.priv) : nullptr;
  if (!self || !self->cartRam || addr >= self->cartRamSize) return 0xFF;
  return self->cartRam[addr];
}

void GameBoyActivity::cartRamWrite(gb_s* state, const uint_fast32_t addr, const uint8_t value) {
  auto* self = state ? static_cast<GameBoyActivity*>(state->direct.priv) : nullptr;
  if (!self || !self->cartRam || addr >= self->cartRamSize) return;
  if (self->cartRam[addr] != value) self->saveDirty = true;
  self->cartRam[addr] = value;
}

void GameBoyActivity::lcdDrawLine(gb_s* state, const uint8_t* pixels, const uint_fast8_t line) {
  auto* self = state ? static_cast<GameBoyActivity*>(state->direct.priv) : nullptr;
  if (self) self->writeGameBoyLine(pixels, line);
}

// A Peanut-GB line: shade in bits 1-0 (0 white..3 black), palette bits above; stored as grey levels.
void GameBoyActivity::writeGameBoyLine(const uint8_t* pixels, const uint_fast8_t line) {
  if (!pixels || line >= GAMEBOY_HEIGHT || !frameBuffers[writeFrame]) return;
  uint8_t* out = frameBuffers[writeFrame] + static_cast<size_t>(line) * GAMEBOY_WIDTH;
  for (int x = 0; x < GAMEBOY_WIDTH; ++x) out[x] = kDmgLevel[pixels[x] & 0x03];
}

void GameBoyActivity::fatalError(gb_s* state, enum gb_error_e errorCode, const uint16_t addr) {
  auto* self = state ? static_cast<GameBoyActivity*>(state->direct.priv) : nullptr;
  if (!self) {
    ESP.restart();
    while (true) delay(1000);
  }
  self->emergencyRestart(static_cast<int>(errorCode), addr);
}

// The core cannot run past the error: save the cartridge RAM and restart.
void GameBoyActivity::emergencyRestart(const int error, const uint16_t addr) {
  LOG_ERR(TAG, "%s fatal error=%d addr=0x%04X", cgb ? "Walnut-CGB" : "Peanut-GB", error, addr);
  if (!saveCartRam()) LOG_ERR(TAG, "Emergency save failed before restart: %s", savePath.c_str());
  ESP.restart();
  while (true) delay(1000);
}

// Walnut-CGB hands over grey levels already (0..16).
void GameBoyActivity::cgbLine(void* user, const uint8_t* levels, const uint_fast8_t line) {
  auto* self = static_cast<GameBoyActivity*>(user);
  if (!self || line >= GAMEBOY_HEIGHT || !self->frameBuffers[self->writeFrame]) return;
  std::memcpy(self->frameBuffers[self->writeFrame] + static_cast<size_t>(line) * GAMEBOY_WIDTH, levels, GAMEBOY_WIDTH);
}

void GameBoyActivity::cgbError(void* user, const int error, const uint16_t addr) {
  auto* self = static_cast<GameBoyActivity*>(user);
  if (!self) {
    ESP.restart();
    while (true) delay(1000);
  }
  self->emergencyRestart(error, addr);
}

void GameBoyActivity::cgbRamWritten(void* user) {
  auto* self = static_cast<GameBoyActivity*>(user);
  if (self) self->saveDirty = true;
}

const char* GameBoyActivity::initErrorString(const int errorCode) {
  switch (static_cast<gb_init_error_e>(errorCode)) {
    case GB_INIT_CARTRIDGE_UNSUPPORTED: return "Unsupported cartridge";
    case GB_INIT_INVALID_CHECKSUM: return "Invalid ROM checksum";
    case GB_INIT_NO_ERROR: return "";
    default: return "Unknown Game Boy ROM error";
  }
}

#endif  // CROSSINK_GAMEBOY
