#pragma once

// The Game Boy screen (X4 Pro, CROSSINK_GAMEBOY): runs a .gb or .gbc ROM on the Peanut-GB core
// (Game Boy) or the Walnut-CGB core (Game Boy Color games), with touch controls under the
// picture, the front buttons, and a Bluetooth controller taught in "Controller setup".
// Ported from the Ink-boy / xteink-pokemon-game fork (MIT), cut down to the emulator itself.

#ifndef GB_FAST_PANEL
#define GB_FAST_PANEL 0
#endif

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string>

#include "GameBoyPad.h"
#include "GfxRenderer.h"
#include "MappedInputManager.h"
#include "activities/RenderLock.h"
#include "activities/Activity.h"

#if CROSSINK_GAMEBOY
#include "walnut_cgb_port.h"

extern "C" {
// The same configuration as src/peanut_gb_impl.c, so both see one gb_s layout.
#define PEANUT_GB_IS_LITTLE_ENDIAN 1
#define ENABLE_SOUND 0
#define ENABLE_LCD 1
#define PEANUT_GB_HEADER_ONLY
#include <peanut_gb.h>
#undef PEANUT_GB_HEADER_ONLY
}

class GameBoyActivity final : public Activity {
 public:
  GameBoyActivity(GfxRenderer& renderer, MappedInputManager& mappedInput, std::string romPath);
  ~GameBoyActivity() override;

  void onEnter() override;
  void onExit() override;
  void loop() override;
  void render(RenderLock&&) override;

  bool skipLoopDelay() override { return true; }
  bool preventAutoSleep() override { return true; }

 private:
  enum class TouchControl : uint8_t { None, Up, Down, Left, Right, A, B, Select, Start, Settings };
  enum class MenuItem : uint8_t { Resume, SaveState, LoadState, WriteSave, TopBar, FastPanel, Exit, Count };

  struct ControlButton {
    TouchControl control;
    int x, y, w, h;
    const char* label;
  };

  static constexpr int GAMEBOY_WIDTH = 160;
  static constexpr int GAMEBOY_HEIGHT = 144;
  static constexpr int SCALE = 3;  // 480 x 432: the full width of the portrait panel
  static constexpr size_t EMULATOR_FRAME_BYTES = GAMEBOY_WIDTH * GAMEBOY_HEIGHT;
  static constexpr uint64_t EMULATION_FRAME_PERIOD_US = 16743ULL;  // 59.73 Hz
  static constexpr uint64_t DISPLAY_PERIOD_US = 20000ULL;          // a new picture goes out as soon as the panel is free
  static constexpr uint8_t MAX_CATCH_UP_FRAMES = 4;
  static constexpr uint8_t DRAW_EVERY = 3;  // one emulated frame in three is drawn
  static constexpr uint64_t AUTOSAVE_PERIOD_US = 60000000ULL;
  static constexpr uint64_t CLEAN_REFRESH_PERIOD_US = 45000000ULL;  // ghost-cleaning refresh
  static constexpr unsigned long EXIT_CHORD_MS = 1200;              // Select + Start held together
  static constexpr size_t MAX_CONTROLS = 10;

  std::string romPath;
  std::string savePath;
  std::string tempSavePath;
  std::string backupSavePath;

  gb_s* gb = nullptr;
  WalnutCgb* cgb = nullptr;
  uint8_t* rom = nullptr;
  size_t romSize = 0;
  uint8_t* cartRam = nullptr;
  size_t cartRamSize = 0;
  bool saveDirty = false;

  // Two picture buffers handed between the emulator task and the render task.
  uint8_t* frameBuffers[2] = {nullptr, nullptr};
  uint8_t writeFrame = 0;
  std::atomic<uint8_t> readyFrame{0xFF};
  std::atomic<uint8_t> renderFrame{0xFF};
  std::atomic<bool> displayDue{true};
  std::atomic<bool> fullRefreshDue{true};
  std::atomic<bool> initialized{false};
  bool exitRequested = false;
  char error[96] = {};
  char title[24] = {};

  uint8_t physicalMask = 0;  // front buttons
  uint8_t touchMask = 0;     // on-screen buttons
  uint8_t padMask = 0;       // Bluetooth controller (joypad bits)
  uint8_t padHeld = 0;       // Bluetooth controller (gbpad::Control bits)
  gbpad::Table padTable;
  gbpad::Link padLink = gbpad::Link::Disabled;
  TouchControl activeTouch = TouchControl::None;
  bool multiTouchActive = false;
  unsigned long chordSinceMs = 0;

  // In-game menu (the settings button): the emulator stands still while it is open.
  std::atomic<bool> menuOpen{false};
  std::atomic<bool> menuDirty{false};
  std::atomic<bool> emuPaused{false};
  std::atomic<bool> emuIdle{true};
  // Leaving the game. onExit() may run with the render lock already held by the activity manager, so it never
  // takes that lock itself: it sets `exiting` (render() then does nothing) and waits for `inRender` to drop.
  std::atomic<bool> exiting{false};
  std::atomic<bool> inRender{false};
  std::atomic<bool> autosaveDue{false};      // the emulator task asks, the loop task writes the .sav
  std::atomic<bool> menuFullRefresh{false};  // repaint the menu with a cleaning refresh (after a panel-mode switch)
  bool menuTouchLatched = false;             // one finger counts once: no repeat until it lifts
  unsigned long menuLockUntilMs = 0;         // taps / keys in the menu are ignored until then (no double activation)
  uint8_t menuSelected = 0;
  bool loadArmed = false;
  bool stateExists = false;
  char menuMessage[64] = {};
  std::string statePath;

  // Settings kept in /.crosspoint/gameboy.cfg.
  bool topBarClock = true;        // clock and battery in the top bar instead of the game's name
  bool fastPanelWanted = false;   // the game-mode panel tuning (only where the SDK has it)
  bool fastActive = false;        // the tuning is on right now

  int gameX = 0;
  int gameY = 40;
  int gameW = GAMEBOY_WIDTH * SCALE;
  int gameH = GAMEBOY_HEIGHT * SCALE;
  ControlButton controls[MAX_CONTROLS] = {};
  size_t controlCount = 0;

  GfxRenderer::Orientation orientationOnEnter = GfxRenderer::Orientation::Portrait;

  TaskHandle_t emuTask = nullptr;
  std::atomic<bool> emuRun{false};
  std::atomic<bool> emuStopped{true};
  uint64_t nextFrameUs = 0;
  uint64_t nextDisplayUs = 0;
  uint64_t nextAutosaveUs = 0;
  uint64_t nextCleanUs = 0;
  uint8_t framesSinceDraw = DRAW_EVERY;

  // One emulated frame in drawEvery() is drawn; the quick panel modes can take more pictures.
  uint8_t drawEvery() const { return fastActive ? 2 : DRAW_EVERY; }

  void renderImpl();
  void doAutosave();
  void setLayout();
  void addControl(TouchControl control, int x, int y, int w, int h, const char* label);
  void drawChrome();
  void drawGameFrame();
  void releaseRenderedFrame();
  bool drawGameFramePortrait(const uint8_t* source, uint8_t* framebuffer);

  void handleInput();
  void handleTouch();
  void loadSettings();
  void saveSettings();
  void drawTopBar();
  bool fastPanelSupported() const;
  // notify = false: switch the panel tuning only (used while leaving, when no screen update may be requested).
  void applyFastPanel(bool on, bool notify = true);
  void menuLabel(int index, char* out, size_t outSize) const;
  void openMenu();
  void closeMenu();
  void handleMenuInput();
  void menuActivate(MenuItem item);
  void drawMenu();
  int menuRowTop() const;
  int menuRowHeight() const;
  bool waitEmuIdle();
  bool writeState(const std::string& path);
  bool readState(const std::string& path);
  void updateTouch(int x, int y);
  TouchControl hitTestTouch(int x, int y) const;
  static uint8_t joypadBitForTouch(TouchControl control);
  void applyJoypad();

  bool loadRom();
  bool buildSavePaths();
  bool initEmulator();
  bool loadSave();
  bool saveCartRam();
  void cleanup();
  void showError(const char* message);
  void setCoreRtc(const struct tm& time);

  void startEmuTask();
  void stopEmuTask();
  static void emuTaskEntry(void* arg);
  void emuTaskLoop();
  void runEmulation(uint64_t nowUs);
  void publishCompletedFrame();

  static uint8_t romRead(gb_s* state, uint_fast32_t addr);
  static uint8_t cartRamRead(gb_s* state, uint_fast32_t addr);
  static void cartRamWrite(gb_s* state, uint_fast32_t addr, uint8_t value);
  static void lcdDrawLine(gb_s* state, const uint8_t* pixels, uint_fast8_t line);
  static void fatalError(gb_s* state, enum gb_error_e errorCode, uint16_t addr);
  static void cgbLine(void* user, const uint8_t* levels, uint_fast8_t line);
  static void cgbError(void* user, int error, uint16_t addr);
  static void cgbRamWritten(void* user);
  void writeGameBoyLine(const uint8_t* pixels, uint_fast8_t line);
  void emergencyRestart(int error, uint16_t addr);
  static const char* initErrorString(int errorCode);
};

#endif  // CROSSINK_GAMEBOY
