#include "GameBoyPad.h"

#include <Arduino.h>
#include <BlePageTurner.h>
#include <HalStorage.h>
#include <Logging.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "CrossPointSettings.h"

namespace gbpad {

namespace {
constexpr char kPadPath[] = "/.crosspoint/gameboy_pad.cfg";
constexpr const char* kNames[ControlCount] = {"UP", "DOWN", "LEFT", "RIGHT", "A", "B", "START", "SELECT"};
constexpr const char* kKeys[ControlCount] = {"up", "down", "left", "right", "a", "b", "start", "select"};
constexpr uint8_t kBits[ControlCount] = {0x40, 0x80, 0x20, 0x10, 0x01, 0x02, 0x08, 0x04};

uint8_t startFailures = 0;
uint32_t nextStartMs = 0;
uint32_t nextPairMs = 0;
}  // namespace

const char* controlName(const Control control) { return control < ControlCount ? kNames[control] : ""; }

uint8_t joypadBit(const Control control) { return control < ControlCount ? kBits[control] : 0; }

bool anyLearned(const Table& table) {
  for (const uint32_t code : table.code) {
    if (code != 0) return true;
  }
  return false;
}

bool load(Table& table) {
  table = Table{};
  HalFile file;
  if (!Storage.openFileForRead("GBPAD", kPadPath, file)) return false;
  char text[256];
  const int got = file.read(text, sizeof(text) - 1);
  file.close();
  if (got <= 0) return false;
  text[got] = '\0';
  char* save = nullptr;
  for (char* line = strtok_r(text, "\r\n", &save); line; line = strtok_r(nullptr, "\r\n", &save)) {
    char* eq = strchr(line, '=');
    if (!eq) continue;
    *eq = '\0';
    for (uint8_t i = 0; i < ControlCount; ++i) {
      if (strcmp(line, kKeys[i]) == 0) table.code[i] = static_cast<uint32_t>(strtoul(eq + 1, nullptr, 10));
    }
  }
  return true;
}

bool save(const Table& table) {
  Storage.ensureDirectoryExists("/.crosspoint");
  HalFile file;
  if (!Storage.openFileForWrite("GBPAD", kPadPath, file)) return false;
  char line[40];
  bool ok = true;
  for (uint8_t i = 0; i < ControlCount; ++i) {
    const int n = snprintf(line, sizeof(line), "%s=%lu\n", kKeys[i], static_cast<unsigned long>(table.code[i]));
    if (n <= 0 || file.write(line, static_cast<size_t>(n)) != static_cast<size_t>(n)) ok = false;
  }
  file.close();
  return ok;
}

void resetService() {
  startFailures = 0;
  nextStartMs = 0;
  nextPairMs = 0;
}

Link service() {
  const auto st = bleturner::status();
  if (!st.compiledIn) return Link::Unavailable;
  if (!SETTINGS.ble.enabled) return Link::Disabled;
  if (st.starting || st.stopping) return Link::Starting;

  const uint32_t now = millis();
  if (!st.running) {
    // The radio is down (a screen change stopped it): start it again on this task. A start can
    // block for a moment, so a failing radio is tried only a few times.
    if (startFailures >= 3) return Link::Unavailable;
    if (now >= nextStartMs) {
      nextStartMs = now + 5000;
      if (!bleturner::switchOn()) {
        ++startFailures;
        LOG_ERR("GBPAD", "Radio start failed (%u)", static_cast<unsigned>(startFailures));
      }
    }
    return Link::Starting;
  }

  bleturner::service();
  if (st.connected) return Link::Connected;
  if (SETTINGS.ble.peerAddr[0] == '\0') return Link::NoRemote;
  if (!st.connecting && now >= nextPairMs) {
    nextPairMs = now + 8000;
    bleturner::pair(SETTINGS.ble.peerAddr, SETTINGS.ble.peerName);
  }
  return Link::Connecting;
}

bool poll(const Table& table, uint8_t& held) {
  bool changed = false;
  bleturner::Event event;
  while (bleturner::pollEvent(event)) {
    for (uint8_t i = 0; i < ControlCount; ++i) {
      if (table.code[i] == 0 || table.code[i] != event.code) continue;
      const uint8_t bit = static_cast<uint8_t>(1u << i);
      const uint8_t next = event.pressed ? static_cast<uint8_t>(held | bit) : static_cast<uint8_t>(held & ~bit);
      if (next != held) {
        held = next;
        changed = true;
      }
    }
  }
  return changed;
}

}  // namespace gbpad
