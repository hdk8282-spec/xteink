#include "GameBoyPad.h"

#include <Arduino.h>
#include <BleKeyBinding.h>
#include <BlePageTurner.h>
#if __has_include(<BleKeyboardHost.h>)
#include <BleKeyboardHost.h>
#define GBPAD_RAW 1
#endif
#include <HalStorage.h>
#include <Logging.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "CrossPointSettings.h"

namespace gbpad {

#if GBPAD_RAW
static void clearSlots();
#endif

namespace {
constexpr char kPadPath[] = "/.crosspoint/gameboy_pad.cfg";
constexpr const char* kNames[ControlCount] = {"UP", "DOWN", "LEFT", "RIGHT", "A", "B", "START", "SELECT"};
constexpr const char* kKeys[ControlCount] = {"up", "down", "left", "right", "a", "b", "start", "select"};
constexpr uint8_t kBits[ControlCount] = {0x40, 0x80, 0x20, 0x10, 0x01, 0x02, 0x08, 0x04};

// Some remotes only ever send "down" (a click) and never "up". Until an "up" has been heard, every down
// is held for a short pulse instead, so a key can neither stick forever nor be missed.
constexpr uint32_t kPulseMs = 250;
bool sawRelease = false;
uint32_t pulseUntil[ControlCount] = {};
uint32_t lastEventCode = 0;
bool lastEventPressed = false;

uint8_t startFailures = 0;
uint32_t nextStartMs = 0;
uint32_t nextPairMs = 0;
}  // namespace

const char* controlName(const Control control) { return control < ControlCount ? kNames[control] : ""; }

uint8_t joypadBit(const Control control) { return control < ControlCount ? kBits[control] : 0; }

bool anyLearned(const Table& table) {
  for (const uint32_t code : table.code) {
    if (code != 0) return true;
  }
  return false;
}

bool load(Table& table) {
  table = Table{};
  HalFile file;
  if (!Storage.openFileForRead("GBPAD", kPadPath, file)) return false;
  char text[256];
  const int got = file.read(text, sizeof(text) - 1);
  file.close();
  if (got <= 0) return false;
  text[got] = '\0';
  char* save = nullptr;
  for (char* line = strtok_r(text, "\r\n", &save); line; line = strtok_r(nullptr, "\r\n", &save)) {
    char* eq = strchr(line, '=');
    if (!eq) continue;
    *eq = '\0';
    for (uint8_t i = 0; i < ControlCount; ++i) {
      if (strcmp(line, kKeys[i]) == 0) table.code[i] = static_cast<uint32_t>(strtoul(eq + 1, nullptr, 10));
    }
  }
  return true;
}

bool save(const Table& table) {
  Storage.ensureDirectoryExists("/.crosspoint");
  HalFile file;
  if (!Storage.openFileForWrite("GBPAD", kPadPath, file)) return false;
  char line[40];
  bool ok = true;
  for (uint8_t i = 0; i < ControlCount; ++i) {
    const int n = snprintf(line, sizeof(line), "%s=%lu\n", kKeys[i], static_cast<unsigned long>(table.code[i]));
    if (n <= 0 || file.write(line, static_cast<size_t>(n)) != static_cast<size_t>(n)) ok = false;
  }
  file.close();
  return ok;
}

void resetService() {
  sawRelease = false;
  for (uint32_t& until : pulseUntil) until = 0;
  lastEventCode = 0;
  lastEventPressed = false;
  startFailures = 0;
  nextStartMs = 0;
  nextPairMs = 0;
#if GBPAD_RAW
  clearSlots();
#endif
}

Link service() {
  const auto st = bleturner::status();
  if (!st.compiledIn) return Link::Unavailable;
  if (!SETTINGS.ble.enabled) return Link::Disabled;
  if (st.starting || st.stopping) return Link::Starting;

  const uint32_t now = millis();
  if (!st.running) {
    // The radio is down (a screen change stopped it): start it again on this task. A start can
    // block for a moment, so a failing radio is tried only a few times.
    if (startFailures >= 3) return Link::Unavailable;
    if (now >= nextStartMs) {
      nextStartMs = now + 5000;
      if (!bleturner::switchOn()) {
        ++startFailures;
        LOG_ERR("GBPAD", "Radio start failed (%u)", static_cast<unsigned>(startFailures));
      }
    }
    return Link::Starting;
  }

  bleturner::service();
  if (st.connected) return Link::Connected;
  if (SETTINGS.ble.peerAddr[0] == '\0') return Link::NoRemote;
  if (!st.connecting && now >= nextPairMs) {
    nextPairMs = now + 8000;
    bleturner::pair(SETTINGS.ble.peerAddr, SETTINGS.ble.peerName);
  }
  return Link::Connecting;
}

bool pollLegacy(const Table& table, uint8_t& held) {
  bool changed = false;
  const uint32_t now = millis();
  bleturner::Event event;
  while (bleturner::pollEvent(event)) {
    lastEventCode = event.code;
    lastEventPressed = event.pressed;
    if (!event.pressed) {
      sawRelease = true;
      // "Everything let go" reports carry no button code: that releases all.
      if (event.code == 0 && held != 0) {
        held = 0;
        changed = true;
        continue;
      }
    }
    for (uint8_t i = 0; i < ControlCount; ++i) {
      if (table.code[i] == 0 || table.code[i] != event.code) continue;
      const uint8_t bit = static_cast<uint8_t>(1u << i);
      if (event.pressed && !sawRelease) pulseUntil[i] = now + kPulseMs;
      const uint8_t next = event.pressed ? static_cast<uint8_t>(held | bit) : static_cast<uint8_t>(held & ~bit);
      if (next != held) {
        held = next;
        changed = true;
      }
    }
  }
  if (!sawRelease && held != 0) {
    for (uint8_t i = 0; i < ControlCount; ++i) {
      const uint8_t bit = static_cast<uint8_t>(1u << i);
      if ((held & bit) && static_cast<int32_t>(now - pulseUntil[i]) >= 0) {
        held = static_cast<uint8_t>(held & ~bit);
        changed = true;
      }
    }
  }
  return changed;
}

void drainLegacy() {
  bleturner::Event event;
  while (bleturner::pollEvent(event)) {
    lastEventCode = event.code;
    lastEventPressed = event.pressed;
    if (!event.pressed) sawRelease = true;
  }
}


#if GBPAD_RAW
namespace {
// A held raw button: the code it arrived with (its release carries the same one) and the controls it drives.
struct Slot {
  uint32_t raw = 0;
  uint8_t mask = 0;
  uint32_t until = 0;  // press-only remotes: when the pulse ends
};
constexpr size_t kSlots = 12;
Slot slots[kSlots];

constexpr uint8_t bitOf(const Control c) { return static_cast<uint8_t>(1u << c); }

// The key a report carries, for a control nobody taught a button: arrows / WASD, Enter X K = A,
// Esc Backspace Z J = B, Space = Start, Tab = Select, the SDK's synthetic gamepad usages, and the
// gamepad report (0xFD: byte 0 direction 1-4, byte 1 button number).
uint8_t defaultMaskFor(const uint32_t code, const uint8_t keycode) {
  const uint8_t reportId = static_cast<uint8_t>((code >> 16) & 0xFF);
  const uint8_t byteIndex = static_cast<uint8_t>((code >> 8) & 0xFF);
  const uint8_t value = static_cast<uint8_t>(code & 0xFF);
  if (reportId == 0xFD) {
    if (byteIndex == 0) {
      switch (value) {
        case 1: return bitOf(Up);
        case 2: return bitOf(Down);
        case 3: return bitOf(Left);
        case 4: return bitOf(Right);
        default: return 0;
      }
    }
    switch (value) {
      case 1: return bitOf(A);
      case 2: return bitOf(B);
      case 3: return bitOf(Select);
      case 4: return bitOf(Start);
      default: return 0;
    }
  }
  switch (keycode) {
    case 0x52: case 0x1A: case 0x43: return bitOf(Up);
    case 0x51: case 0x16: case 0x45: return bitOf(Down);
    case 0x50: case 0x04: case 0x41: case 0x42: return bitOf(Left);
    case 0x4F: case 0x07: case 0x46: return bitOf(Right);
    case 0x28: case 0x1B: case 0x0E: case 0x47: return bitOf(A);
    case 0x29: case 0x2A: case 0x1D: case 0x0D: case 0x48: return bitOf(B);
    case 0x2C: return bitOf(Start);
    case 0x2B: return bitOf(Select);
    default: return 0;
  }
}

uint8_t maskFor(const Table& table, const uint32_t raw, const uint8_t keycode) {
  const uint32_t learned = bleturner::learnableCode(raw, keycode);
  uint8_t mask = 0;
  for (uint8_t i = 0; i < ControlCount; ++i) {
    if (table.code[i] != 0 && (table.code[i] == learned || table.code[i] == raw)) mask |= bitOf(static_cast<Control>(i));
  }
  if (mask) return mask;
  // Not a taught button: a default key, for a control that has no taught button of its own.
  uint8_t def = defaultMaskFor(raw, keycode);
  for (uint8_t i = 0; i < ControlCount; ++i) {
    if (table.code[i] != 0) def &= static_cast<uint8_t>(~bitOf(static_cast<Control>(i)));
  }
  return def;
}

uint8_t slotsHeld() {
  uint8_t held = 0;
  for (const Slot& slot : slots) held |= slot.mask;
  return held;
}

}  // namespace

static void clearSlots() {
  for (Slot& slot : slots) slot = Slot{};
}

bool poll(const Table& table, uint8_t& held) {
  const uint32_t now = millis();
  freeink::RawButtonEvent event;
  while (BleHid.popRawButton(event)) {
    const uint32_t code = event.code();
    lastEventCode = code;
    lastEventPressed = event.pressed;
    if (event.pressed) {
      if (event.wasRest) continue;  // the remote idling on a non-zero byte
      const uint8_t mask = maskFor(table, code, event.keycode);
      if (!mask) continue;
      size_t use = kSlots;
      for (size_t i = 0; i < kSlots; ++i) {
        if (slots[i].raw == code) { use = i; break; }
        if (use == kSlots && slots[i].raw == 0) use = i;
      }
      if (use < kSlots) slots[use] = Slot{code, mask, now + kPulseMs};
    } else {
      sawRelease = true;
      // Releases keep the press's code; a release with none ("everything let go") frees all.
      for (Slot& slot : slots) {
        if (code == 0 || slot.raw == code) slot = Slot{};
      }
    }
  }
  if (!sawRelease) {
    for (Slot& slot : slots) {
      if (slot.raw != 0 && static_cast<int32_t>(now - slot.until) >= 0) slot = Slot{};
    }
  }
  const uint8_t next = slotsHeld();
  const bool changed = next != held;
  held = next;
  return changed;
}

void drain() {
  freeink::RawButtonEvent event;
  while (BleHid.popRawButton(event)) {
    lastEventCode = event.code();
    lastEventPressed = event.pressed;
    if (!event.pressed) sawRelease = true;
  }
  clearSlots();
}
#else
bool poll(const Table& table, uint8_t& held) { return pollLegacy(table, held); }
void drain() { drainLegacy(); }
#endif

uint32_t lastCode() { return lastEventCode; }
bool lastPressed() { return lastEventPressed; }

}  // namespace gbpad
