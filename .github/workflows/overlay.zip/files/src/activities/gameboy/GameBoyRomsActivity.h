#pragma once

#include <string>
#include <vector>

#include "activities/UiListActivity.h"

class GfxRenderer;
class MappedInputManager;

// System menu > Game Boy: the first row opens "Controller setup", the others are the .gb / .gbc
// ROMs found in /gameboy, /roms, /gb and /games on the SD card.
class GameBoyRomsActivity final : public UiListActivity {
 public:
  GameBoyRomsActivity(GfxRenderer& renderer, MappedInputManager& mappedInput);

  void onEnter() override;

 private:
  int listCount() const override { return static_cast<int>(items_.size()); }
  void buildScreen(UiScreen& screen) override;
  void activateIndex(int index) override;
  const char* headerTitle() const override;

  void rescan();
  void rebuildRows();

  struct Rom {
    std::string path;
    std::string name;    // file name without the extension
    std::string folder;  // shown as the row's value
  };
  std::vector<Rom> roms_;
  std::vector<std::string> labels_;
  std::vector<std::string> values_;
  std::vector<freeink::ui::ListItem> items_;
};
