#pragma once

// Bluetooth controller for the Game Boy screens, built on the page turner's radio
// (lib/BlePageTurner). The radio, pairing and bonds belong to that module (Settings >
// Bluetooth page turner); this only keeps it up while a Game Boy screen is open, reads the
// raw button edges of the linked remote, and maps them to the eight Game Boy controls by
// the codes the user taught in "Controller setup".

#include <cstdint>

namespace gbpad {

enum Control : uint8_t { Up, Down, Left, Right, A, B, Start, Select, ControlCount };

// One learned button code per control (0 = not learned), saved in /.crosspoint/gameboy_pad.cfg.
struct Table {
  uint32_t code[ControlCount] = {};
};

const char* controlName(Control control);
// The Peanut-GB joypad bit of a control (A 0x01, B 0x02, Select 0x04, Start 0x08, Right 0x10, ...).
uint8_t joypadBit(Control control);
bool anyLearned(const Table& table);
bool load(Table& table);
bool save(const Table& table);

enum class Link : uint8_t { Unavailable, Disabled, Starting, NoRemote, Connecting, Connected };

// Forget earlier failed starts (call when a Game Boy screen opens).
void resetService();
// Keeps the radio up and the chosen remote linked. Call every loop pass; returns where it is.
Link service();
// Drains the remote's edges into `held` (one bit per Control). True when `held` changed.
bool poll(const Table& table, uint8_t& held);

}  // namespace gbpad
