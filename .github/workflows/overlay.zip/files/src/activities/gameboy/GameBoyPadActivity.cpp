#include "GameBoyPadActivity.h"

#include <Arduino.h>
#include <BlePageTurner.h>
#include <I18n.h>
#include <Logging.h>

#include <cstdio>
#include <memory>

#include "CrossPointSettings.h"
#include "activities/settings/BleSettingsActivity.h"
#include "components/UITheme.h"
#include "fontIds.h"

GameBoyPadActivity::GameBoyPadActivity(GfxRenderer& rendererIn, MappedInputManager& mappedInputIn)
    : Activity("GameBoyPad", rendererIn, mappedInputIn) {}

void GameBoyPadActivity::onEnter() {
  Activity::onEnter();
  gbpad::load(table);
  gbpad::resetService();
  link = gbpad::Link::Disabled;
  mode = Mode::Menu;
  selected = 0;
  touchLatched = true;
  dirty = true;
  requestUpdate();
}

void GameBoyPadActivity::onExit() { Activity::onExit(); }

int GameBoyPadActivity::menuTop() const {
  const auto& m = UITheme::getInstance().getMetrics();
  return m.topPadding + m.headerHeight + 3 * (renderer.getLineHeight(UI_FONT_ID) + 6) + 24;
}

int GameBoyPadActivity::menuRowHeight() const { return renderer.getLineHeight(UI_FONT_ID) + 26; }

const char* GameBoyPadActivity::linkText() const {
  switch (link) {
    case gbpad::Link::Unavailable: return tr(STR_GB_LINK_UNAVAILABLE);
    case gbpad::Link::Disabled: return tr(STR_GB_LINK_DISABLED);
    case gbpad::Link::Starting: return tr(STR_GB_LINK_STARTING);
    case gbpad::Link::NoRemote: return tr(STR_GB_LINK_NOREMOTE);
    case gbpad::Link::Connecting: return tr(STR_GB_LINK_CONNECTING);
    case gbpad::Link::Connected: return tr(STR_GB_LINK_CONNECTED);
  }
  return "";
}

void GameBoyPadActivity::activateRow(const int row) {
  if (row == 0) {
    startActivityForResult(std::make_unique<BleSettingsActivity>(renderer, mappedInput),
                           [this](const ActivityResult&) {
                             gbpad::resetService();
                             dirty = true;
                             requestUpdate();
                           });
  } else if (row == 1) {
    startLearning();
  } else if (row == 2) {
    table = gbpad::Table{};
    gbpad::save(table);
    dirty = true;
    requestUpdate();
  }
}

void GameBoyPadActivity::startLearning() {
  touchLatched = true;  // the finger that chose this row is still down
  backup = table;
  mode = Mode::Learn;
  learnIndex = 0;
  phase = Phase::Calibrate;
  phaseSinceMs = millis();
  learnSinceMs = phaseSinceMs;
  waitRelease = false;
  heldCode = 0;
  blockCode = 0;
  noiseCount = 0;
  for (uint8_t& hits : noiseHits) hits = 0;
  noiseFull = false;
  lastCode = 0;
  lastPressed = false;
  eventTotal = 0;
  bleturner::Event drop;
  while (bleturner::pollEvent(drop)) {
  }
  dirty = true;
  requestUpdate();
}

void GameBoyPadActivity::finishLearning(const bool saveTable) {
  if (saveTable) {
    gbpad::save(table);
  } else {
    table = backup;
  }
  mode = Mode::Menu;
  dirty = true;
  requestUpdate();
}

bool GameBoyPadActivity::isNoise(const uint32_t code) const {
  for (uint8_t i = 0; i < noiseCount; ++i) {
    if (noise[i] == code) return noiseHits[i] >= NOISE_MIN_HITS;
  }
  return false;
}

uint8_t GameBoyPadActivity::noisyCount() const {
  uint8_t n = 0;
  for (uint8_t i = 0; i < noiseCount; ++i) {
    if (noiseHits[i] >= NOISE_MIN_HITS) ++n;
  }
  return n;
}

// Counts what the controller sends while nobody touches it. A code only counts as chatter once it repeats:
// a press the user makes by mistake during that time (down + up) stays learnable.
void GameBoyPadActivity::addNoise(const uint32_t code) {
  for (uint8_t i = 0; i < noiseCount; ++i) {
    if (noise[i] == code) {
      if (noiseHits[i] < 255) ++noiseHits[i];
      return;
    }
  }
  if (noiseCount < MAX_NOISE) {
    noise[noiseCount] = code;
    noiseHits[noiseCount] = 1;
    ++noiseCount;
  } else {
    noiseFull = true;
  }
}

// The next control. Whatever the controller sends during the first moments of a step is dropped, so a button
// that is still being let go (or a signal that comes by itself) cannot fill the step in before the user acts.
void GameBoyPadActivity::advanceLearning() {
  blockCode = heldCode;
  ++learnIndex;
  phase = Phase::Wait;
  phaseSinceMs = millis();
  learnSinceMs = phaseSinceMs;
  waitRelease = false;
  heldCode = 0;
  bleturner::Event drop;
  while (bleturner::pollEvent(drop)) {
  }
  if (learnIndex >= gbpad::ControlCount) {
    finishLearning(true);
    return;
  }
  dirty = true;
  requestUpdate();
}

// One pass of the learning screen: the next press of the controller names the control asked for.
void GameBoyPadActivity::stepLearning() {
  const unsigned long now = millis();

  if (phase == Phase::Calibrate && now - phaseSinceMs >= CALIBRATE_MS) {
    LOG_INF("GBPAD", "Idle signals: %u chattering codes of %u%s, %u events", static_cast<unsigned>(noisyCount()),
            static_cast<unsigned>(noiseCount),
            noiseFull ? "+" : "", static_cast<unsigned>(eventTotal));
    phase = Phase::Wait;
    phaseSinceMs = now;
    learnSinceMs = now;
    bleturner::Event drop;
    while (bleturner::pollEvent(drop)) {
    }
    dirty = true;
    requestUpdate();
    return;
  }

  bleturner::Event e;
  while (bleturner::pollEvent(e)) {
    ++eventTotal;
    lastCode = e.code;
    lastPressed = e.pressed;
    LOG_INF("GBPAD", "event code=%lu %s phase=%u idx=%d", static_cast<unsigned long>(e.code),
            e.pressed ? "down" : "up", static_cast<unsigned>(phase), learnIndex);

    if (phase == Phase::Calibrate) {
      addNoise(e.code);  // hands off: this is the controller's own chatter
      dirty = true;
      continue;
    }
    if (e.code == blockCode && !e.pressed) blockCode = 0;
    if (isNoise(e.code)) continue;

    if (phase == Phase::Wait) {
      if (now - phaseSinceMs < SETTLE_MS) continue;
      if (e.pressed && e.code != 0 && e.code != blockCode) {
        // A button belongs to one control only.
        for (uint32_t& code : table.code) {
          if (code == e.code) code = 0;
        }
        table.code[learnIndex] = e.code;
        heldCode = e.code;
        phase = Phase::Captured;
        capturedMs = now;
        waitRelease = true;
        dirty = true;
        requestUpdate();
      }
    } else if (phase == Phase::Captured) {
      if (!e.pressed && e.code == heldCode) {
        advanceLearning();
        return;
      }
    }
  }
  if (dirty) requestUpdate();

  if (phase == Phase::Captured && now - capturedMs >= CAPTURE_HOLD_MS) {
    // Some remotes never report the lift: go on anyway (the button's repeats are blocked next).
    advanceLearning();
    return;
  }
  if (phase == Phase::Wait && now - learnSinceMs >= LEARN_TIMEOUT_MS) advanceLearning();
}

void GameBoyPadActivity::loop() {
  using Button = MappedInputManager::Button;

  const gbpad::Link before = link;
  link = gbpad::service();
  if (link != before) {
    dirty = true;
    requestUpdate();
  }

  int tx = 0, ty = 0;
  int hx = 0, hy = 0;
  if (!mappedInput.isScreenTouchHeld(hx, hy)) touchLatched = false;  // lifted: the next touch counts again
  const bool touched = mappedInput.wasScreenTouchDown(tx, ty) && !touchLatched;
  if (touched) touchLatched = true;

  if (mode == Mode::Learn) {
    stepLearning();
    if (mode != Mode::Learn) return;
    const bool guarded = millis() - phaseSinceMs < SKIP_GUARD_MS;
    if (mappedInput.wasPressed(Button::Back)) {
      finishLearning(false);
    } else if (!guarded && phase == Phase::Wait &&
               (mappedInput.wasPressed(Button::Confirm) ||
                // Only the lower part of the screen (the hint buttons) skips: a stray touch elsewhere does not.
                (touched && ty > renderer.getScreenHeight() - 160))) {
      advanceLearning();  // skip this control
    }
    return;
  }

  if (mappedInput.wasPressed(Button::Up)) {
    selected = (selected + ROW_COUNT - 1) % ROW_COUNT;
    dirty = true;
    requestUpdate();
  } else if (mappedInput.wasPressed(Button::Down)) {
    selected = (selected + 1) % ROW_COUNT;
    dirty = true;
    requestUpdate();
  } else if (mappedInput.wasPressed(Button::Confirm)) {
    activateRow(selected);
  } else if (mappedInput.wasPressed(Button::Back)) {
    finish();
    return;
  }

  if (touched) {
    const int top = menuTop();
    const int rowH = menuRowHeight();
    if (ty >= top && ty < top + ROW_COUNT * rowH) {
      selected = (ty - top) / rowH;
      activateRow(selected);
    }
  }
}

void GameBoyPadActivity::render(RenderLock&&) {
  const int w = renderer.getScreenWidth();
  const int h = renderer.getScreenHeight();
  const auto& m = UITheme::getInstance().getMetrics();
  const int lh = renderer.getLineHeight(UI_FONT_ID);
  char line[96];

  renderer.clearScreen();
  GUI.drawHeader(renderer, Rect{0, m.topPadding, w, m.headerHeight}, tr(STR_GB_CONTROLLER));

  int y = m.topPadding + m.headerHeight + 12;
  snprintf(line, sizeof(line), "%s", linkText());
  renderer.drawText(UI_FONT_ID, 16, y, line, true);
  y += lh + 6;

  if (mode == Mode::Learn) {
    if (phase == Phase::Calibrate) {
      renderer.drawCenteredText(UI_FONT_ID, h / 2 - 20, tr(STR_GB_LEARN_WAIT), true, EpdFontFamily::BOLD);
    } else {
      snprintf(line, sizeof(line), "%d/%d  %s  %s", learnIndex + 1, static_cast<int>(gbpad::ControlCount),
               gbpad::controlName(static_cast<gbpad::Control>(learnIndex)), tr(STR_GB_PRESS));
      renderer.drawCenteredText(UI_FONT_ID, h / 2 - 20, line, true, EpdFontFamily::BOLD);
      if (phase == Phase::Captured) renderer.drawCenteredText(UI_FONT_ID, h / 2 + 20, "OK", true);
    }
    // What the controller is sending: tells a silent link from a chattering one.
    snprintf(line, sizeof(line), "%s %u   code %lu %s   n=%lu", tr(STR_GB_LEARN_IGNORED),
             static_cast<unsigned>(noisyCount()), static_cast<unsigned long>(lastCode), lastPressed ? "v" : "^",
             static_cast<unsigned long>(eventTotal));
    renderer.drawCenteredText(UI_10_FONT_ID, h / 2 + 80, line, true);
    const auto labels = mappedInput.mapLabels(tr(STR_CANCEL), tr(STR_GB_SKIP), "", "");
    GUI.drawButtonHints(renderer, labels.btn1, labels.btn2, labels.btn3, labels.btn4);
    renderer.displayBuffer();
    dirty = false;
    return;
  }

  // What is learned so far, four controls to a line.
  for (int i = 0; i < gbpad::ControlCount; i += 4) {
    int n = 0;
    line[0] = '\0';
    for (int j = i; j < i + 4 && j < gbpad::ControlCount; ++j) {
      n += snprintf(line + n, sizeof(line) - n, "%s%s%s", j == i ? "" : "   ",
                    gbpad::controlName(static_cast<gbpad::Control>(j)), table.code[j] ? " o" : " -");
    }
    renderer.drawText(UI_FONT_ID, 16, y, line, true);
    y += lh + 6;
  }

  const char* rows[ROW_COUNT] = {tr(STR_GB_BT_SETUP), tr(STR_GB_LEARN), tr(STR_GB_CLEAR)};
  const int top = menuTop();
  const int rowH = menuRowHeight();
  for (int i = 0; i < ROW_COUNT; ++i) {
    const int ry = top + i * rowH;
    renderer.drawRoundedRect(8, ry, w - 16, rowH - 8, i == selected ? 4 : 1, 10, true);
    renderer.drawText(UI_FONT_ID, 24, ry + (rowH - 8 - lh) / 2, rows[i], true);
  }

  const auto labels = mappedInput.mapLabels(tr(STR_BACK), tr(STR_SELECT), "", "");
  GUI.drawButtonHints(renderer, labels.btn1, labels.btn2, labels.btn3, labels.btn4);
  renderer.displayBuffer();
  dirty = false;
}
