#include "GameBoyPadActivity.h"

#include <Arduino.h>
#include <BlePageTurner.h>
#include <I18n.h>
#include <Logging.h>

#include <cstdio>
#include <memory>

#include "CrossPointSettings.h"
#include "activities/settings/BleSettingsActivity.h"
#include "components/UITheme.h"
#include "fontIds.h"

GameBoyPadActivity::GameBoyPadActivity(GfxRenderer& rendererIn, MappedInputManager& mappedInputIn)
    : Activity("GameBoyPad", rendererIn, mappedInputIn) {}

void GameBoyPadActivity::onEnter() {
  Activity::onEnter();
  gbpad::load(table);
  gbpad::resetService();
  link = gbpad::Link::Disabled;
  mode = Mode::Menu;
  selected = 0;
  dirty = true;
  requestUpdate();
}

void GameBoyPadActivity::onExit() { Activity::onExit(); }

int GameBoyPadActivity::menuTop() const {
  const auto& m = UITheme::getInstance().getMetrics();
  return m.topPadding + m.headerHeight + 3 * (renderer.getLineHeight(UI_FONT_ID) + 6) + 24;
}

int GameBoyPadActivity::menuRowHeight() const { return renderer.getLineHeight(UI_FONT_ID) + 26; }

const char* GameBoyPadActivity::linkText() const {
  switch (link) {
    case gbpad::Link::Unavailable: return tr(STR_GB_LINK_UNAVAILABLE);
    case gbpad::Link::Disabled: return tr(STR_GB_LINK_DISABLED);
    case gbpad::Link::Starting: return tr(STR_GB_LINK_STARTING);
    case gbpad::Link::NoRemote: return tr(STR_GB_LINK_NOREMOTE);
    case gbpad::Link::Connecting: return tr(STR_GB_LINK_CONNECTING);
    case gbpad::Link::Connected: return tr(STR_GB_LINK_CONNECTED);
  }
  return "";
}

void GameBoyPadActivity::activateRow(const int row) {
  if (row == 0) {
    startActivityForResult(std::make_unique<BleSettingsActivity>(renderer, mappedInput),
                           [this](const ActivityResult&) {
                             gbpad::resetService();
                             dirty = true;
                             requestUpdate();
                           });
  } else if (row == 1) {
    startLearning();
  } else if (row == 2) {
    table = gbpad::Table{};
    gbpad::save(table);
    dirty = true;
    requestUpdate();
  }
}

void GameBoyPadActivity::startLearning() {
  backup = table;
  mode = Mode::Learn;
  learnIndex = 0;
  learnSinceMs = millis();
  waitRelease = false;
  heldCode = 0;
  bleturner::Event drop;
  while (bleturner::pollEvent(drop)) {
  }
  dirty = true;
  requestUpdate();
}

void GameBoyPadActivity::finishLearning(const bool saveTable) {
  if (saveTable) {
    gbpad::save(table);
  } else {
    table = backup;
  }
  mode = Mode::Menu;
  dirty = true;
  requestUpdate();
}

void GameBoyPadActivity::advanceLearning() {
  ++learnIndex;
  learnSinceMs = millis();
  waitRelease = false;
  heldCode = 0;
  if (learnIndex >= gbpad::ControlCount) {
    finishLearning(true);
    return;
  }
  dirty = true;
  requestUpdate();
}

// One pass of the learning screen: the next press of the controller names the control asked for.
void GameBoyPadActivity::stepLearning() {
  bleturner::Event e;
  while (bleturner::pollEvent(e)) {
    if (waitRelease) {
      if (!e.pressed && e.code == heldCode) {
        advanceLearning();
        return;
      }
      continue;
    }
    if (e.pressed && e.code != 0) {
      // A button belongs to one control only.
      for (uint32_t& code : table.code) {
        if (code == e.code) code = 0;
      }
      table.code[learnIndex] = e.code;
      heldCode = e.code;
      waitRelease = true;
      dirty = true;
      requestUpdate();
    }
  }
  if (!waitRelease && millis() - learnSinceMs >= LEARN_TIMEOUT_MS) advanceLearning();
}

void GameBoyPadActivity::loop() {
  using Button = MappedInputManager::Button;

  const gbpad::Link before = link;
  link = gbpad::service();
  if (link != before) {
    dirty = true;
    requestUpdate();
  }

  if (mode == Mode::Learn) {
    stepLearning();
    if (mappedInput.wasPressed(Button::Confirm)) {
      advanceLearning();  // skip this control
    } else if (mappedInput.wasPressed(Button::Back)) {
      finishLearning(false);
    }
    int tx = 0, ty = 0;
    if (mappedInput.wasScreenTouchDown(tx, ty)) advanceLearning();
    return;
  }

  if (mappedInput.wasPressed(Button::Up)) {
    selected = (selected + ROW_COUNT - 1) % ROW_COUNT;
    dirty = true;
    requestUpdate();
  } else if (mappedInput.wasPressed(Button::Down)) {
    selected = (selected + 1) % ROW_COUNT;
    dirty = true;
    requestUpdate();
  } else if (mappedInput.wasPressed(Button::Confirm)) {
    activateRow(selected);
  } else if (mappedInput.wasPressed(Button::Back)) {
    finish();
    return;
  }

  int x = 0, y = 0;
  if (mappedInput.wasScreenTouchDown(x, y)) {
    const int top = menuTop();
    const int rowH = menuRowHeight();
    if (y >= top && y < top + ROW_COUNT * rowH) {
      selected = (y - top) / rowH;
      activateRow(selected);
    }
  }
}

void GameBoyPadActivity::render(RenderLock&&) {
  const int w = renderer.getScreenWidth();
  const int h = renderer.getScreenHeight();
  const auto& m = UITheme::getInstance().getMetrics();
  const int lh = renderer.getLineHeight(UI_FONT_ID);
  char line[96];

  renderer.clearScreen();
  GUI.drawHeader(renderer, Rect{0, m.topPadding, w, m.headerHeight}, tr(STR_GB_CONTROLLER));

  int y = m.topPadding + m.headerHeight + 12;
  snprintf(line, sizeof(line), "%s", linkText());
  renderer.drawText(UI_FONT_ID, 16, y, line, true);
  y += lh + 6;

  if (mode == Mode::Learn) {
    snprintf(line, sizeof(line), "%d/%d  %s  %s", learnIndex + 1, static_cast<int>(gbpad::ControlCount),
             gbpad::controlName(static_cast<gbpad::Control>(learnIndex)), tr(STR_GB_PRESS));
    renderer.drawCenteredText(UI_FONT_ID, h / 2 - 20, line, true, EpdFontFamily::BOLD);
    if (waitRelease) renderer.drawCenteredText(UI_FONT_ID, h / 2 + 20, "OK", true);
    const auto labels = mappedInput.mapLabels(tr(STR_CANCEL), tr(STR_GB_SKIP), "", "");
    GUI.drawButtonHints(renderer, labels.btn1, labels.btn2, labels.btn3, labels.btn4);
    renderer.displayBuffer();
    return;
  }

  // What is learned so far, four controls to a line.
  for (int i = 0; i < gbpad::ControlCount; i += 4) {
    int n = 0;
    line[0] = '\0';
    for (int j = i; j < i + 4 && j < gbpad::ControlCount; ++j) {
      n += snprintf(line + n, sizeof(line) - n, "%s%s%s", j == i ? "" : "   ",
                    gbpad::controlName(static_cast<gbpad::Control>(j)), table.code[j] ? " o" : " -");
    }
    renderer.drawText(UI_FONT_ID, 16, y, line, true);
    y += lh + 6;
  }

  const char* rows[ROW_COUNT] = {tr(STR_GB_BT_SETUP), tr(STR_GB_LEARN), tr(STR_GB_CLEAR)};
  const int top = menuTop();
  const int rowH = menuRowHeight();
  for (int i = 0; i < ROW_COUNT; ++i) {
    const int ry = top + i * rowH;
    renderer.drawRoundedRect(8, ry, w - 16, rowH - 8, i == selected ? 4 : 1, 10, true);
    renderer.drawText(UI_FONT_ID, 24, ry + (rowH - 8 - lh) / 2, rows[i], true);
  }

  const auto labels = mappedInput.mapLabels(tr(STR_BACK), tr(STR_SELECT), "", "");
  GUI.drawButtonHints(renderer, labels.btn1, labels.btn2, labels.btn3, labels.btn4);
  renderer.displayBuffer();
  dirty = false;
}
