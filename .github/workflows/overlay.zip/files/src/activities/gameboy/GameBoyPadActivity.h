#pragma once

#include <cstdint>

#include "GameBoyPad.h"
#include "GfxRenderer.h"
#include "MappedInputManager.h"
#include "activities/Activity.h"
#include "activities/RenderLock.h"

// Game Boy > Controller setup: opens the Bluetooth page turner settings to pair a controller,
// and teaches the eight Game Boy controls the buttons of the linked controller one by one.
class GameBoyPadActivity final : public Activity {
 public:
  GameBoyPadActivity(GfxRenderer& renderer, MappedInputManager& mappedInput);

  void onEnter() override;
  void onExit() override;
  void loop() override;
  void render(RenderLock&&) override;

 private:
  enum class Mode : uint8_t { Menu, Learn };
  static constexpr int ROW_COUNT = 3;  // pair, learn, clear
  static constexpr unsigned long LEARN_TIMEOUT_MS = 15000;

  Mode mode = Mode::Menu;
  int selected = 0;
  gbpad::Table table;
  gbpad::Table backup;  // the table when learning began, restored on cancel
  gbpad::Link link = gbpad::Link::Disabled;
  int learnIndex = 0;
  unsigned long learnSinceMs = 0;
  bool waitRelease = false;
  uint32_t heldCode = 0;
  bool dirty = true;

  int menuTop() const;
  int menuRowHeight() const;
  void activateRow(int row);
  void startLearning();
  void finishLearning(bool saveTable);
  void advanceLearning();
  void stepLearning();
  const char* linkText() const;
};
