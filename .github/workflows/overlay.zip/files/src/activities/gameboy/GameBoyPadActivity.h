#pragma once

#include <cstdint>

#include "GameBoyPad.h"
#include "GfxRenderer.h"
#include "MappedInputManager.h"
#include "activities/Activity.h"
#include "activities/RenderLock.h"

// Game Boy > Controller setup: opens the Bluetooth page turner settings to pair a controller,
// and teaches the eight Game Boy controls the buttons of the linked controller one by one.
class GameBoyPadActivity final : public Activity {
 public:
  GameBoyPadActivity(GfxRenderer& renderer, MappedInputManager& mappedInput);

  void onEnter() override;
  void onExit() override;
  void loop() override;
  void render(RenderLock&&) override;

 private:
  enum class Mode : uint8_t { Menu, Learn };
  // Learn: Calibrate (hands off: whatever the controller sends now is idle noise and is ignored from then on),
  // Wait (the next press of a non-noise button names the control), Captured (waiting for the button to lift).
  enum class Phase : uint8_t { Calibrate, Wait, Captured };
  static constexpr int ROW_COUNT = 3;  // pair, learn, clear
  static constexpr unsigned long LEARN_TIMEOUT_MS = 15000;
  static constexpr unsigned long CALIBRATE_MS = 1500;   // idle listening before the first control is asked
  static constexpr unsigned long SETTLE_MS = 500;       // after each step starts: every signal is dropped
  static constexpr unsigned long CAPTURE_HOLD_MS = 900;  // go on this long after a press even if no lift is reported
  static constexpr unsigned long SKIP_GUARD_MS = 700;    // Confirm / touch cannot skip right after a step began
  static constexpr uint8_t MAX_NOISE = 12;
  static constexpr uint8_t NOISE_MIN_HITS = 4;  // one real press is two signals (down, up): chatter repeats more

  Mode mode = Mode::Menu;
  int selected = 0;
  gbpad::Table table;
  gbpad::Table backup;  // the table when learning began, restored on cancel
  gbpad::Link link = gbpad::Link::Disabled;
  int learnIndex = 0;
  unsigned long learnSinceMs = 0;
  bool waitRelease = false;
  uint32_t heldCode = 0;
  Phase phase = Phase::Calibrate;
  unsigned long phaseSinceMs = 0;
  unsigned long capturedMs = 0;
  uint32_t blockCode = 0;  // the button just learned: its repeats are not the next control
  uint32_t noise[MAX_NOISE] = {};
  uint8_t noiseHits[MAX_NOISE] = {};
  uint8_t noiseCount = 0;  // distinct codes heard while idle
  bool noiseFull = false;
  uint32_t lastCode = 0;
  bool lastPressed = false;
  uint32_t eventTotal = 0;
  bool dirty = true;
  bool touchLatched = false;  // one finger counts once: no repeat until it lifts

  int menuTop() const;
  int menuRowHeight() const;
  void activateRow(int row);
  void startLearning();
  void finishLearning(bool saveTable);
  void advanceLearning();
  void stepLearning();
  bool isNoise(uint32_t code) const;
  uint8_t noisyCount() const;
  void addNoise(uint32_t code);
  const char* linkText() const;
};
