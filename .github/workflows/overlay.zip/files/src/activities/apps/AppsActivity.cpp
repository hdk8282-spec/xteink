#include "AppsActivity.h"

#include <GfxRenderer.h>
#include <HalDisplay.h>
#include <HalStorage.h>
#include <I18n.h>
#include <Logging.h>
#include <ZipFile.h>

#include <algorithm>
#include <cctype>
#include <memory>
#include <string_view>

#include "MappedInputManager.h"
#include "activities/RenderLock.h"
#include "activities/apps/lua/AppPaths.h"
#include "activities/apps/lua/LuaAppActivity.h"
#include "components/UITheme.h"

namespace fui = freeink::ui;

namespace {

bool endsWithZip(const std::string& name) {
  if (name.size() < 5) return false;
  const std::string ext = name.substr(name.size() - 4);
  return std::tolower(static_cast<unsigned char>(ext[0])) == '.' &&
         std::tolower(static_cast<unsigned char>(ext[1])) == 'z' &&
         std::tolower(static_cast<unsigned char>(ext[2])) == 'i' &&
         std::tolower(static_cast<unsigned char>(ext[3])) == 'p';
}

// A path inside an app must stay inside the app folder.
bool safeRelativePath(const std::string& rel) {
  if (rel.empty() || rel[0] == '/' || rel[0] == '\\') return false;
  if (rel.find("..") != std::string::npos) return false;
  if (rel.find('\\') != std::string::npos) return false;
  return true;
}

}  // namespace

AppsActivity::AppsActivity(GfxRenderer& renderer, MappedInputManager& mappedInput)
    : UiListActivity("Apps", renderer, mappedInput) {}

const char* AppsActivity::headerTitle() const { return tr(STR_APPS); }

void AppsActivity::onEnter() {
  UiListActivity::onEnter();
  rescan();
}

void AppsActivity::rescan() {
  apps_ = AppPackage::scanApplications();
  std::sort(apps_.begin(), apps_.end(), [](const AppPackage& a, const AppPackage& b) { return a.name < b.name; });

  zips_.clear();
  if (Storage.exists(app_paths::DROP_DIR)) {
    HalFile dir = Storage.open(app_paths::DROP_DIR);
    if (dir && dir.isDirectory()) {
      char name[128];
      for (HalFile entry = dir.openNextFile(); entry; entry = dir.openNextFile()) {
        name[0] = '\0';
        entry.getName(name, sizeof(name));
        const bool isDir = entry.isDirectory();
        entry.close();
        if (!isDir && endsWithZip(name)) zips_.push_back(std::string(app_paths::DROP_DIR) + "/" + name);
      }
    }
    if (dir) dir.close();
  }
  std::sort(zips_.begin(), zips_.end());
  rebuildRows();
}

// Row layout: [message] [apps...] [zips...]. Row text lives in labels_/values_,
// which are sized once so the pointers kept in items_ stay valid.
void AppsActivity::rebuildRows() {
  const size_t extra = message_.empty() ? 0 : 1;
  const size_t total = extra + apps_.size() + zips_.size();
  labels_.assign(total, std::string());
  values_.assign(total, std::string());
  items_.clear();
  items_.reserve(total + 1);

  size_t row = 0;
  if (extra) {
    labels_[row] = message_;
    fui::ListItem item;
    item.label = labels_[row].c_str();
    item.actionValue = static_cast<int16_t>(row);
    items_.push_back(item);
    ++row;
  }
  for (size_t i = 0; i < apps_.size(); ++i, ++row) {
    labels_[row] = apps_[i].name;
    values_[row] = app_paths::supportsThisDevice(apps_[i].devices) ? apps_[i].version : std::string(tr(STR_APPS_NOT_FOR_DEVICE));
    fui::ListItem item;
    item.label = labels_[row].c_str();
    item.value = values_[row].c_str();
    item.actionValue = static_cast<int16_t>(row);
    items_.push_back(item);
  }
  for (size_t i = 0; i < zips_.size(); ++i, ++row) {
    const size_t slash = zips_[i].find_last_of('/');
    labels_[row] = std::string(tr(STR_APPS_INSTALL)) + ": " + zips_[i].substr(slash == std::string::npos ? 0 : slash + 1);
    fui::ListItem item;
    item.label = labels_[row].c_str();
    item.actionValue = static_cast<int16_t>(row);
    items_.push_back(item);
  }
  if (items_.empty()) {
    labels_.assign(1, std::string(tr(STR_APPS_NONE)));
    values_.assign(1, std::string());
    fui::ListItem item;
    item.label = labels_[0].c_str();
    item.actionValue = 0;
    items_.push_back(item);
  }
}

void AppsActivity::buildScreen(UiScreen& screen) {
  const auto& metrics = UITheme::getInstance().getMetrics();
  const Rect safe = UITheme::getInstance().getScreenSafeArea(renderer, true, false);
  screen.setContentMarginFromScreen(fui::Insets{
      static_cast<int16_t>(safe.y + metrics.topPadding + metrics.headerHeight),
      static_cast<int16_t>(renderer.getScreenWidth() - (safe.x + safe.width)),
      static_cast<int16_t>(renderer.getScreenHeight() - (safe.y + safe.height)), static_cast<int16_t>(safe.x)});
  screen.spacer(static_cast<int16_t>(metrics.verticalSpacing));

  fui::ListProps props;
  props.items = items_.data();
  props.count = static_cast<uint16_t>(items_.size());
  props.action = ACTION_ROW;
  props.inputMask = fui::InputTouch;  // physical buttons stay in loop()
  props.valueInset = 8;
  props.labelText = screen.theme().smallText;
  props.labelText.maxLines = 2;
  syncListViewport(screen, props);
  screen.list(props);
}

// UiListActivity hands back the row index. Rows: [message] [apps...] [zips...], or one hint row
// when there is nothing at all.
void AppsActivity::activateIndex(const int index) {
  if (index < 0 || index >= static_cast<int>(items_.size())) return;
  app.clearTapFlash();
  nav.selected = index;

  const size_t offset = message_.empty() ? 0 : 1;
  if (static_cast<size_t>(index) < offset) return;  // the install message row
  const size_t k = static_cast<size_t>(index) - offset;
  if (k >= apps_.size() + zips_.size()) return;  // the "no apps" hint row

  if (k >= apps_.size()) {
    const size_t zi = k - apps_.size();
    {
      RenderLock lock(*this);
      GUI.drawPopup(renderer, tr(STR_APPS_INSTALLING));
      renderer.displayBuffer(HalDisplay::FAST_REFRESH);
    }
    const bool ok = installZip(zips_[zi]);
    message_ = ok ? tr(STR_APPS_INSTALLED) : tr(STR_APPS_INSTALL_FAILED);
    rescan();
    nav.selected = 0;
    requestUpdate();
    return;
  }

  const AppPackage& pkg = apps_[k];
  if (!app_paths::supportsThisDevice(pkg.devices)) return;

  startActivityForResult(std::make_unique<LuaAppActivity>(renderer, mappedInput, pkg.path, pkg.name, pkg.entryScript),
                         [this](const ActivityResult&) {
                           renderer.clearScreen();
                           renderer.displayBuffer(HalDisplay::FULL_REFRESH);
                           requestUpdate();
                         });
}

// Extracts <app>/... from a ZIP into /.crosspoint/apps/<app>. If every file sits
// under one top-level folder, that folder is the app id; otherwise the ZIP's own
// name is. The ZIP is deleted after a successful install.
bool AppsActivity::installZip(const std::string& zipPath) {
  ZipFile zip(zipPath);
  std::vector<std::string> names;
  if (!zip.enumerateFilePaths([&names](std::string_view p) { names.emplace_back(p); }) || names.empty()) {
    LOG_ERR("APPS", "Cannot read %s", zipPath.c_str());
    return false;
  }

  std::string top;
  bool allUnderOneFolder = true;
  bool hasFile = false;
  for (const auto& n : names) {
    if (n.empty() || n.back() == '/') continue;
    hasFile = true;
    const size_t slash = n.find('/');
    if (slash == std::string::npos) {
      allUnderOneFolder = false;
      break;
    }
    const std::string first = n.substr(0, slash);
    if (top.empty()) {
      top = first;
    } else if (top != first) {
      allUnderOneFolder = false;
      break;
    }
  }
  if (!hasFile) return false;

  std::string id = top;
  if (!allUnderOneFolder) {
    const size_t slash = zipPath.find_last_of('/');
    id = zipPath.substr(slash == std::string::npos ? 0 : slash + 1);
    id = id.substr(0, id.size() - 4);  // drop ".zip"
  }
  if (!safeRelativePath(id) || id.find('/') != std::string::npos || id.front() == '.') return false;

  const std::string dest = app_paths::installDirFor(id);
  Storage.ensureDirectoryExists(app_paths::INSTALL_DIR);
  Storage.ensureDirectoryExists(dest.c_str());

  bool allOk = true;
  for (const auto& n : names) {
    if (n.empty() || n.back() == '/') continue;
    const std::string rel = allUnderOneFolder ? n.substr(top.size() + 1) : n;
    if (!safeRelativePath(rel)) {
      LOG_ERR("APPS", "Skipping unsafe path %s", n.c_str());
      allOk = false;
      continue;
    }
    const std::string full = dest + "/" + rel;
    const size_t slash = rel.find_last_of('/');
    if (slash != std::string::npos) Storage.ensureDirectoryExists((dest + "/" + rel.substr(0, slash)).c_str());

    HalFile out;
    if (!Storage.openFileForWrite("APPS", full, out)) {
      LOG_ERR("APPS", "Cannot write %s", full.c_str());
      allOk = false;
      continue;
    }
    const bool extracted = zip.readFileToStream(n.c_str(), out, 1024);
    out.flush();
    out.close();
    if (!extracted) {
      LOG_ERR("APPS", "Extract failed: %s", n.c_str());
      allOk = false;
    }
  }

  if (allOk) Storage.remove(zipPath.c_str());
  return allOk;
}
