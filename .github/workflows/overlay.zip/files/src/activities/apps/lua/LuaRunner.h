#pragma once

#include <atomic>
#include <cstdint>
#include <functional>
#include <string>

extern "C" {
#include "lauxlib.h"
#include "lua.h"
#include "lualib.h"
}

class GfxRenderer;
class MappedInputManager;

namespace ink {

class LuaRunner {
 public:
  LuaRunner(GfxRenderer& renderer, MappedInputManager& input, const std::string& appDir, const std::string& appId);
  ~LuaRunner();

  bool init();
  bool loadScript(const std::string& scriptPath);
  void shutdown();

  // Lifecycle dispatches
  void onInit();
  void onUpdate();
  void onDraw();
  void onButton(const char* buttonName, bool isPressed);
  void onTouch(int x, int y, const char* eventType);
  void onTap(int x, int y);
  void onSwipe(const char* dir);
  void onExit();

  bool checkAndClearRedrawRequested() {
    bool r = redrawRequested_;
    redrawRequested_ = false;
    return r;
  }

  bool shouldExit() const { return requestedExit_; }
  // smudge.open_guide() asked for the app's guide; cleared by the call.
  bool takeGuideRequest() {
    const bool r = guideRequested_;
    guideRequested_ = false;
    return r;
  }
  bool hasError() const { return hasError_; }
  const std::string& getErrorMessage() const { return errorMessage_; }

  // Memory figures for the apps memory log (AppMemoryLog).
  size_t luaHeapLimitBytes() const { return maxLuaHeapBytes_; }
  size_t luaPeakBytes() const { return peakAllocatedBytes_; }
  // Lowest system free heap seen by an allocation; 0 where it is not measured
  // (simulator, PSRAM boards).
  uint32_t minFreeHeapBytes() const { return minFreeHeap_; }
  uint32_t refusedAllocations() const { return refusedAllocations_; }

  // Whether the app asked (smudge.prevent_sleep) to keep the reader awake.
  // Read on the main task while Lua may run on the render task.
  bool preventsSleep() const { return preventSleep_.load(std::memory_order_relaxed); }

 private:
  GfxRenderer& renderer_;
  MappedInputManager& input_;
  std::string appDir_;
  std::atomic<bool> preventSleep_{false};
  std::string appId_;
  std::string saveDir_;

  lua_State* L = nullptr;
  bool requestedExit_ = false;
  bool guideRequested_ = false;
  bool hasError_ = false;
  bool redrawRequested_ = false;
  std::string errorMessage_;

  // Memory sandbox tracking
  size_t currentAllocatedBytes_ = 0;
  size_t maxLuaHeapBytes_ = 0;
  size_t peakAllocatedBytes_ = 0;
  uint32_t minFreeHeap_ = 0;
  uint32_t refusedAllocations_ = 0;

  static void* customLuaAlloc(void* ud, void* ptr, size_t osize, size_t nsize);

  std::string bytecodePath(const std::string& scriptPath) const;
  int loadChunk(const std::string& scriptPath);
  void precompileApp();

  void registerSmudgeApi();
  void setError(const char* msg);

  // C-to-Lua Bridge functions
  static int l_dofile(lua_State* L);
  static int l_clear(lua_State* L);
  static int l_refresh(lua_State* L);
  static int l_text(lua_State* L);
  static int l_centeredText(lua_State* L);
  static int l_textWidth(lua_State* L);
  static int l_wrappedText(lua_State* L);
  static int l_lineHeight(lua_State* L);
  static int l_pixel(lua_State* L);
  static int l_line(lua_State* L);
  static int l_thickLine(lua_State* L);
  static int l_rect(lua_State* L);
  static int l_rectDither(lua_State* L);
  static int l_roundedRect(lua_State* L);
  static int l_circle(lua_State* L);
  static int l_heart(lua_State* L);
  static int l_bitmap(lua_State* L);
  static int l_getBounds(lua_State* L);
  static int l_getMetrics(lua_State* L);
  static int l_buttonHints(lua_State* L);
  static int l_header(lua_State* L);
  static int l_save(lua_State* L);
  static int l_load(lua_State* L);
  static int l_readFile(lua_State* L);
  static int l_findSection(lua_State* L);
  static int l_fileExists(lua_State* L);
  static int l_exit(lua_State* L);
  static int l_hasGuide(lua_State* L);
  static int l_openGuide(lua_State* L);
  static int l_log(lua_State* L);
  static int l_time(lua_State* L);
  static int l_getDate(lua_State* L);
  static int l_random(lua_State* L);
  static int l_millis(lua_State* L);
  static int l_requestUpdate(lua_State* L);
  static int l_isButtonDown(lua_State* L);
  static int l_drawSprite(lua_State* L);
  static int l_fullRefresh(lua_State* L);
  static int l_invertRect(lua_State* L);
  static int l_invertScreen(lua_State* L);
  static int l_triangle(lua_State* L);
  static int l_inRect(lua_State* L);
  static int l_hasTouch(lua_State* L);
  static int l_getBattery(lua_State* L);
  static int l_getDevice(lua_State* L);
  static int l_writeFile(lua_State* L);
  static int l_listFiles(lua_State* L);
  static int l_deleteFile(lua_State* L);
  static int l_popup(lua_State* L);
  static int l_getMemory(lua_State* L);
  static int l_preventSleep(lua_State* L);
  static int l_setOrientation(lua_State* L);
};

}  // namespace ink
