#pragma once

#include <memory>
#include <mutex>
#include <string>

#include "GfxRenderer.h"
#include "MappedInputManager.h"
#include "activities/Activity.h"
#include "activities/apps/lua/LuaRunner.h"
#include "components/UITheme.h"
#include "fontIds.h"

// Runs one Lua app: forwards buttons and touch to the script, calls its
// on_update() every loop pass and its on_draw() when a redraw is requested.
class LuaAppActivity : public Activity {
 public:
  LuaAppActivity(GfxRenderer& renderer, MappedInputManager& mappedInput, const std::string& appDir,
                 const std::string& appName, const std::string& entryScript = "main.lua")
      : Activity(appName, renderer, mappedInput), appDir_(appDir), appName_(appName), entryScript_(entryScript) {
    const size_t lastSlash = appDir_.find_last_of("/\\");
    if (lastSlash != std::string::npos && lastSlash + 1 < appDir_.length()) {
      appId_ = appDir_.substr(lastSlash + 1);
    } else {
      appId_ = appName_;
    }
  }

  void onEnter() override {
    Activity::onEnter();
    orientationOnEnter_ = renderer.getOrientation();
    runner_ = std::make_unique<ink::LuaRunner>(renderer, mappedInput, appDir_, appId_);

    if (!runner_->init()) {
      initError_ = "Lua init failed";
      requestUpdate();
      return;
    }
    if (!runner_->loadScript(appDir_ + "/" + entryScript_)) {
      requestUpdate();
      return;
    }
    {
      std::lock_guard<std::mutex> lock(luaMutex_);
      runner_->onInit();
    }
    requestUpdate();
  }

  bool preventAutoSleep() override { return runner_ && runner_->preventsSleep(); }

  void loop() override {
    if (!runner_) {
      finish();
      return;
    }
    if (runner_->shouldExit()) {
      finish();
      return;
    }
    if (runner_->hasError() || !initError_.empty()) {
      if (mappedInput.wasReleased(MappedInputManager::Button::Back) ||
          mappedInput.wasReleased(MappedInputManager::Button::Confirm)) {
        finish();
      }
      return;
    }

    bool handled = false;
    const auto press = [&](MappedInputManager::Button b, const char* name) {
      if (mappedInput.wasReleased(b)) {
        std::lock_guard<std::mutex> lock(luaMutex_);
        runner_->onButton(name, true);
        handled = true;
      }
    };
    press(MappedInputManager::Button::Back, "back");
    press(MappedInputManager::Button::Confirm, "confirm");
    press(MappedInputManager::Button::Left, "left");
    press(MappedInputManager::Button::Right, "right");
    press(MappedInputManager::Button::Up, "up");
    press(MappedInputManager::Button::PageBack, "page_back");
    press(MappedInputManager::Button::Down, "down");
    press(MappedInputManager::Button::PageForward, "page_forward");

    int lx = 0, ly = 0;
    if (mappedInput.wasScreenLongPress(lx, ly)) {
      std::lock_guard<std::mutex> lock(luaMutex_);
      runner_->onTouch(lx, ly, "long_press");
      handled = true;
    }

    int tx = 0, ty = 0;
    if (mappedInput.wasScreenTapped(tx, ty)) {
      std::lock_guard<std::mutex> lock(luaMutex_);
      runner_->onTap(tx, ty);
      runner_->onTouch(tx, ty, "tap");
      handled = true;
    }

    const auto swipe = mappedInput.wasSwipe();
    if (swipe != MappedInputManager::SwipeDir::None) {
      const char* dir = "none";
      if (swipe == MappedInputManager::SwipeDir::Up) dir = "up";
      else if (swipe == MappedInputManager::SwipeDir::Down) dir = "down";
      else if (swipe == MappedInputManager::SwipeDir::Left) dir = "left";
      else if (swipe == MappedInputManager::SwipeDir::Right) dir = "right";
      std::lock_guard<std::mutex> lock(luaMutex_);
      runner_->onSwipe(dir);
      handled = true;
    }

    {
      std::lock_guard<std::mutex> lock(luaMutex_);
      runner_->onUpdate();
    }

    if (handled || runner_->checkAndClearRedrawRequested()) {
      if (runner_->shouldExit()) {
        finish();
        return;
      }
      requestUpdate();
    }
  }

  void render(RenderLock&&) override {
    if (!runner_) return;
    if (!initError_.empty()) {
      renderError(initError_.c_str());
      return;
    }
    if (runner_->hasError()) {
      renderError(runner_->getErrorMessage().c_str());
      return;
    }
    {
      std::lock_guard<std::mutex> lk(luaMutex_);
      runner_->onDraw();
    }
    if (runner_->hasError()) {
      renderError(runner_->getErrorMessage().c_str());
      return;
    }
    renderer.displayBuffer();
  }

  void onExit() override {
    {
      std::lock_guard<std::mutex> lock(luaMutex_);
      if (runner_) {
        runner_->onExit();
        runner_->shutdown();
        runner_.reset();
      }
    }
    renderer.setOrientation(orientationOnEnter_);  // smudge.set_orientation() may have turned it
    Activity::onExit();
  }

 private:
  std::string appDir_;
  std::string appName_;
  std::string entryScript_;
  std::string appId_;
  std::string initError_;
  std::unique_ptr<ink::LuaRunner> runner_;
  std::mutex luaMutex_;
  GfxRenderer::Orientation orientationOnEnter_ = GfxRenderer::Orientation::Portrait;

  void renderError(const char* msg) {
    const int w = renderer.getScreenWidth();
    const int h = renderer.getScreenHeight();
    const auto& m = UITheme::getInstance().getMetrics();

    renderer.clearScreen();
    GUI.drawHeader(renderer, Rect{0, m.topPadding, w, m.headerHeight}, appName_.c_str());
    renderer.drawCenteredText(UI_FONT_ID, h / 2 - 40, "App error", true, EpdFontFamily::BOLD);
    if (msg) {
      const auto lines = renderer.wrappedText(UI_FONT_ID, msg, w - 64, 5);
      int y = h / 2 - 10;
      for (const auto& line : lines) {
        renderer.drawCenteredText(UI_FONT_ID, y, line.c_str(), true);
        y += renderer.getLineHeight(UI_FONT_ID) + 2;
      }
    }
    const auto labels = mappedInput.mapLabels(tr(STR_BACK), tr(STR_SELECT), "", "");
    GUI.drawButtonHints(renderer, labels.btn1, labels.btn2, labels.btn3, labels.btn4);
    renderer.displayBuffer();
  }
};
