#pragma once

#include <string>
#include <vector>

#include "activities/UiListActivity.h"
#include "activities/apps/lua/AppPackage.h"

class GfxRenderer;
class MappedInputManager;

// System menu > Apps: lists the Lua apps found on the SD card and runs one.
// Apps can be copied as folders into /apps, or dropped as .zip files into
// /apps and installed from the same list.
class AppsActivity final : public UiListActivity {
 public:
  AppsActivity(GfxRenderer& renderer, MappedInputManager& mappedInput);

  void onEnter() override;

 private:
  int listCount() const override { return static_cast<int>(items_.size()); }
  void buildScreen(UiScreen& screen) override;
  void activateIndex(int index) override;
  const char* headerTitle() const override;

  void rescan();
  void rebuildRows();
  bool installZip(const std::string& zipPath);

  std::vector<AppPackage> apps_;
  std::vector<std::string> zips_;       // full paths of .zip files waiting in /apps
  std::vector<std::string> labels_;     // row label text (items_ point into it)
  std::vector<std::string> values_;     // row value text
  std::vector<freeink::ui::ListItem> items_;
  std::string message_;                 // last install result, shown as the first row
};
