#pragma once

#include <HalGPIO.h>
#include <HalStorage.h>

#include <string>
#include <vector>

// Where the Lua app platform keeps its files on the SD card.
namespace app_paths {

// Apps installed from a ZIP, one folder per app id.
constexpr const char* INSTALL_DIR = "/.crosspoint/apps";
// Per-app saved data (smudge.save/load), one folder per app id.
constexpr const char* DATA_DIR = "/.crosspoint/apps-data";
// Compiled-chunk cache for app scripts.
constexpr const char* CACHE_DIR = "/.crosspoint/cache/apps";
// Visible folder: copy app folders or app .zip files here (USB or the web file manager).
constexpr const char* DROP_DIR = "/apps";

// Folders scanned for apps, INSTALL_DIR first. An app copied by hand as a folder
// into /apps shows up without installing.
constexpr const char* SCAN_DIRS[] = {INSTALL_DIR, DROP_DIR, "/applications", "/.crosssmudge/applications"};

// Reader name used by an app's "devices" list and smudge.get_device().
inline const char* deviceId() {
#if defined(BOARD_HAS_PSRAM)
  return "x4pro";
#else
  // One firmware runs on the X3 and the X4: ask the board which one this is.
  return gpio.deviceIsX3() ? "x3" : "x4";
#endif
}

// An app without a "devices" list runs everywhere.
inline bool supportsThisDevice(const std::vector<std::string>& devices) {
  if (devices.empty()) return true;
  for (const auto& d : devices) {
    if (d == deviceId()) return true;
  }
  return false;
}

inline std::string installDirFor(const std::string& appId) { return std::string(INSTALL_DIR) + "/" + appId; }

}  // namespace app_paths
