#pragma once

// SSD1677 panel driver — Xteink X4 and the de-link ESP32-S3 board (both drive
// an 800x480 GDEQ0426T82 over the same controller). B/W with software 2-bit
// grayscale via a custom LUT, dual-RAM (BW 0x24 / RED 0x26) differential fast
// refresh. Active-HIGH BUSY.
//
// Nothing device-specific is hardcoded in the driver: geometry and SPI clock
// come from BoardConfig, and every tunable waveform value (booster soft-start,
// scan direction, grayscale LUTs, refresh temperature) is supplied through an
// Ssd1677Config. A board reuses the generic driver by passing its own config;
// the firmware just calls the generic EInkDisplay API and gets device behavior.

#include "PanelDriver.h"

namespace freeink {

// Device-tunable SSD1677 waveform/config. A board overrides only what differs.
struct Ssd1677Config {
  uint8_t booster[5];            // booster soft-start (CMD 0x0C)
  uint8_t driverOutputScan;      // CMD 0x01 base scan byte (0x02); mirrorY ORs TB
  uint8_t borderWaveformInit;    // CMD 0x3C value written during controller init
  uint8_t halfRefreshTemp;       // temperature byte written for HALF refresh
  const unsigned char* grayLut;  // 110-byte custom LUT for grayscale display
  // Absolute Display Update Control 2 (0x22) sequence values, per refresh type.
  // 0 = use the driver's built-in X4 values (incremental, keeps the panel powered
  // between fast refreshes). A panel whose OTP waveform isn't selected by the X4
  // values supplies its vendor-published values here — they pick the waveform
  // (full vs partial/DU), load temperature, and self-cycle power. Setting these
  // makes fast refreshes use the panel's real DU waveform instead of running the
  // full waveform every time. (e.g. Sticky: full 0xF7 / fast 0xFF, from Seeed's
  // SSD1677 driver.) Ignored while a custom grayscale LUT is active.
  uint8_t fullSeqOverride = 0;  // FULL refreshes
  uint8_t fastSeqOverride = 0;  // FAST (UI) refreshes
  uint8_t halfSeqOverride = 0;  // HALF refreshes; 0 falls back to fullSeqOverride
  // Border waveform (CMD 0x3C) re-written per refresh in the seqOverride path so
  // it tracks the refresh mode (vendor parity); without this a partial/DU refresh
  // leaves the border driven dark (Sticky's black ring). 0 = keep the init value.
  // Only consulted when fullSeqOverride / fastSeqOverride are set.
  uint8_t borderWaveformFull = 0;  // FULL refreshes
  uint8_t borderWaveformFast = 0;  // FAST (UI / page-turn) refreshes
  uint8_t borderWaveformHalf = 0;  // HALF refreshes; 0 falls back to borderWaveformFull
  // Border waveform while a custom (grayscale/revert) LUT is loaded. A follow-LUT
  // border value (0x0X) makes the border track a row of the loaded LUT; under the
  // grayscale LUT that drives the border black on every AA refresh. 0x80 (VCOM)
  // holds it undriven at a defined potential. 0 = leave the register untouched.
  uint8_t borderWaveformGray = 0;
  // Power the rails up in a separate activation before a custom-LUT (grayscale/
  // revert) refresh. Boards whose vendor sequences self-power-down after every
  // refresh (Sticky: fast 0xFF) otherwise fold CLOCK_ON|ANALOG_ON into the same
  // activation as the gray waveform; the LUT's 1-frame phases then run while the
  // booster is still ramping and under-drive the grays (lighter AA, mid-grays
  // collapsing toward B/W). The X4 keeps the panel powered between fast
  // refreshes, so it never needs this and keeps stock behavior.
  bool grayPowerUpFirst = false;
  // Configurations supporting the factory four-tone LUT advertise it.
  bool absoluteGrayscale = false;
  // Boards without characterized grayscale waveforms must not advertise AA.
  bool overlayGrayscale = true;
  bool writeSecondUpdateControlByte = false;  // append zero to CMD 0x21
  bool restoreInternalTemperature = false;    // CMD 0x18=0x80 after warmed HALF
  bool blackPulseClean = false;  // HALF: two partials old -> black -> new (Metalio demo)
  // Factory absolute 4-level LUT override; nullptr selects lut_factory_quality.
  // Boards with a per-module voltage tail (Metalio) point this at their copy.
  const unsigned char* factoryGrayLut = nullptr;
  // 110-byte B/W LUT for FAST refreshes, activated with 0xCC instead of the OTP
  // fastSeqOverride; nullptr keeps the OTP waveform.
  const unsigned char* fastLut = nullptr;
  // 110-byte B/W LUTs for FULL / HALF refreshes, for panels whose OTP waveforms
  // are not used. Activated with 0xE4 (FULL, loads temperature) / 0xC4 (HALF,
  // halfRefreshTemp written) instead of the OTP sequences; nullptr keeps OTP.
  const unsigned char* fullLut = nullptr;
  const unsigned char* halfLut = nullptr;
};

// Standard config (Xteink X4 / GDEQ0426T82). Panel mounting (mirror/180°) is NOT
// a config field — it comes from BoardProfile.orientation so any board injects it
// uniformly. -DFREEINK_DISPLAY_FLIPPED is an alias for mirrorY.
const Ssd1677Config& ssd1677DefaultConfig();

class Ssd1677Driver : public PanelDriver {
 public:
  const char* controllerName() const override { return "SSD1677"; }
  explicit Ssd1677Driver(const Ssd1677Config& cfg = ssd1677DefaultConfig());

  uint32_t spiHz() const override;
  BusyPolarity busyPolarity() const override { return BusyPolarity::ActiveHigh; }
  PanelGeometry geometry() const override;

  void begin(EpdBus& bus) override;
  void deepSleep(EpdBus& bus) override;
  void powerOffBetweenFrames(EpdBus& bus) override;

  void display(EpdBus& bus, const uint8_t* fb, const uint8_t* prev, RefreshMode mode, bool turnOff) override;
  // Deferred refresh: displayStart() runs the full update (RAM writes,
  // MASTER_ACTIVATION) and returns while the waveform runs; displayFinish()
  // sleeps out the remainder on the BUSY completion edge. No post-waveform
  // host-frame work on X4 (RED handling is inside displayImpl's async path).
  bool displayStart(EpdBus& bus, const uint8_t* fb, const uint8_t* prev, RefreshMode mode, bool turnOff) override;
  void displayFinish(EpdBus& bus, const uint8_t* fb) override;
  bool supportsAsyncDisplay() const override { return true; }
  void displayWindow(EpdBus& bus, const uint8_t* fb, const uint8_t* prev, uint16_t x, uint16_t y, uint16_t w,
                     uint16_t h, bool turnOff) override;

  void requestResync(uint8_t) override { _needsGrayClear = true; _absoluteInput = false; _lastFrameValid = false; }
  void beginGrayscale(EpdBus& bus, const uint8_t* fb, GrayscaleMode mode, RefreshMode fallback, bool turnOff) override;

  void seedPreviousFrame(EpdBus& bus, const uint8_t* buf) override;

  GrayscaleCapabilities grayscaleCapabilities(GrayscaleMode mode = GrayscaleMode::Overlay) const override {
    if (mode == GrayscaleMode::Absolute && _cfg.absoluteGrayscale)
      return {GrayscaleEncoding::AbsolutePlanes, GrayscaleBase::Combined, true, false, false};
    if (mode != GrayscaleMode::Overlay || !_cfg.overlayGrayscale) return {};
    return {GrayscaleEncoding::OverlayMasks, GrayscaleBase::Separate, true, true, false};
  }
  void copyGrayscaleLsb(EpdBus& bus, const uint8_t* lsb) override;
  void copyGrayscaleMsb(EpdBus& bus, const uint8_t* msb) override;
  void writeGrayscalePlaneStrip(EpdBus& bus, GrayPlane plane, const uint8_t* rows, uint16_t yStart,
                                uint16_t numRows) override;
  void displayGray(EpdBus& bus, const uint8_t* fb, bool turnOff, const unsigned char* lut, bool factoryMode) override;
  void cleanupGrayscaleBuffers(EpdBus& bus, const uint8_t* bw) override;

  // No grayscaleRevert override. Grayscale exits via cleanupGrayscaleBuffers
  // (RED resync) or a promoted single-pass HALF clean in displayImpl/displayWindow.
  // Stock 7.4.4 has a dedicated grey_revert waveform, but it is not yet ported.
  void setCustomLut(EpdBus& bus, bool enabled, const unsigned char* data) override;

  // xteink-pokemon equivalent for the SSD1677 (X4 Pro). Game mode = setFastRefreshDiffWindow(true):
  //  - FAST refreshes use the incremental CTRL2=0x1C DU path (about 80 ms) instead of the stock 0xFC
  //    sequence (about 500 ms); the stock sequence still runs when the temperature must be reloaded.
  //  - only the rectangle that changed since the last refresh is sent over SPI, and a frame that did
  //    not change starts no refresh at all (displayStart() then returns false).
  // The UC8279-only knobs (forced PLL / temperature, scaled DU waveform) are not needed here: the
  // SSD1677 DU waveform is already short, so DuScale and Tuning stay no-ops.
  void setFastRefreshDiffWindow(bool on) override;

 private:
  bool _pendingFrameSync = false;
  bool _needsGrayClear = false;
  bool _absoluteInput = false;
  void writeGrayRam(EpdBus& bus, uint8_t command, const uint8_t* data, uint16_t len);
  void initController(EpdBus& bus);
  void setRamArea(EpdBus& bus, uint16_t x, uint16_t y, uint16_t w, uint16_t h);
  void writeRam(EpdBus& bus, uint8_t ramCmd, const uint8_t* data, uint32_t size);
  // async: fire MASTER_ACTIVATION and return without waiting on BUSY.
  void refresh(EpdBus& bus, RefreshMode mode, bool turnOff, bool async = false);
  // Blocking CLOCK_ON|ANALOG_ON activation; no-op when already powered.
  void powerOn(EpdBus& bus);
  // Documented SSD1677 analog/oscillator shutdown. Used after a 0xFC update
  // when turnOff was requested and by deepSleep().
  void powerOffController(EpdBus& bus, uint16_t settleMs = 200);
  bool displayImpl(EpdBus& bus, const uint8_t* fb, const uint8_t* prev, RefreshMode mode, bool turnOff, bool async);
  bool displayGameWindow(EpdBus& bus, const uint8_t* fb, bool turnOff, bool async);
  void writeLastFrameRed(EpdBus& bus, uint16_t xb, uint16_t y, uint16_t wb, uint16_t h);

  const Ssd1677Config& _cfg;

  uint16_t _w;
  uint16_t _h;
  uint16_t _wb;
  uint32_t _bufferSize;

  // Panel mount transform from BoardProfile.orientation (mirrorX via RAM column
  // addressing in setRamArea, mirrorY via the gate-scan direction). 180° = both.
  bool _mirrorX = false;
  bool _mirrorY = false;

  bool _isScreenOn = false;
  bool _inGrayscaleMode = false;
  bool _customLutActive = false;
  // Async 0xFC updates cannot issue the separate power-off activation until the
  // display waveform completes; displayFinish() consumes this flag.
  bool _pendingPowerOff = false;
  // First paint after begin() (boot or deep-sleep wake) must be a full refresh to
  // clear whatever is physically on the panel (e.g. the black boot screen) and set
  // a clean differential baseline. Only armed for boards whose self-powering fast
  // sequence makes _isScreenOn useless as a cold-start signal (fullSeqOverride set).
  bool _needsInitialFull = false;

  // ---- game mode (see setFastRefreshDiffWindow) ----
  bool _gameMode = false;
  uint8_t* _lastFrame = nullptr;   // copy of the displayed frame; controller BW and RED planes equal it
  bool _lastFrameValid = false;
  bool _tempStale = true;          // the 0x1C path does not reload the temperature: run one stock refresh first
  uint16_t _gameRefreshes = 0;     // refreshes since the temperature was loaded
  uint8_t _slowRefreshes = 0;      // consecutive refreshes that ran long (0x1C promoted to a slow waveform)
  bool _winSyncPending = false;    // RED plane still to be rewritten from _lastFrame once the waveform ends
  uint16_t _syncXb = 0, _syncY = 0, _syncWb = 0, _syncH = 0;
  uint32_t _fireMs = 0;
  bool _timeThisRefresh = false;
};

// Singleton accessor (Meyers, zero-heap). Selects the config for the active board.
PanelDriver& ssd1677Driver();

#if FREEINK_DEVICE_PICCO
// Onyx Picco panel probe (cached): reads the panel ID over the display pins
// before the SPI bus starts and records it in ACTIVE.displayControllerVariant.
enum PiccoPanel : uint8_t {
  PiccoUnknown = 0,
  PiccoYrd0426 = 1,
  PiccoDepg0397 = 2,
  PiccoOpm040b3 = 3,
  PiccoSe0400nqw47 = 4,  // the stock "SSD2677" driver path (Ssd2677Driver)
};
uint8_t piccoProbePanel();
#endif

#if FREEINK_DEVICE_STICKY
// Sticky panel probe (cached): true when the unit carries an SSD2677 instead of
// the SSD1677 (CMD 0x70 answers 0x07).
bool stickyHasSsd2677();
#endif

}  // namespace freeink
