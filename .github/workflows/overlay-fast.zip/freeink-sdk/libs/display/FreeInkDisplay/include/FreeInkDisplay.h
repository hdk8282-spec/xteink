#pragma once

// FreeInk SDK — display facade.
//
// FreeInkDisplay is the stable, hardware-independent display API the firmware
// calls. It owns the framebuffer(s) and geometry and delegates every panel
// operation to a PanelDriver selected at begin(). Drivers per controller
// (SSD1677, UC8253-X3, ED2208-M5, UC8253-Murphy) live in standalone files and
// are linked per build; X3 and X4 are both linked in the generic ESP32-C3 bin
// and chosen at runtime (setDisplayX3()), so one binary drives both.
//
// The public surface below is byte-compatible with the EInkDisplay API, so
// firmware builds unchanged through the EInkDisplay.h alias.

#include <Arduino.h>
#include <BoardConfig.h>  // device flags (sizes the framebuffer for the largest panel)
#include <SPI.h>

#include "../src/bus/EpdBus.h"
#include "GrayscaleCapabilities.h"

namespace freeink {

class PanelDriver;

class FreeInkDisplay {
 public:
  // Legacy pin arguments are retained for source compatibility. begin() uses
  // BoardConfig::ACTIVE.display, including any runtime-selected board profile.
  FreeInkDisplay(int8_t sclk, int8_t mosi, int8_t cs, int8_t dc, int8_t rst, int8_t busy);
  ~FreeInkDisplay() = default;

  // Refresh modes (public contract — full / balanced-half / fast).
  enum RefreshMode { FULL_REFRESH, HALF_REFRESH, FAST_REFRESH };

  // Select panel geometry/controller before begin().
  void setDisplayX3();
  void setDisplayM5PaperColor();

  // M5 PaperColor: run the next refresh's OTP waveform to completion (one-shot).
  void requestCompleteWaveformNextRefresh();

  // M5 PaperColor: make every FULL_REFRESH run the complete OTP waveform
  // (~15 s, DC-balanced, true white, full color) instead of an interrupted
  // full-panel pass. For consumers whose Full refreshes are all standing
  // images (clock/dashboard apps); readers that page with Full keep the
  // default (off). No-op on other panels.
  void setFullRefreshCompletesWaveform(bool enabled);

  // M5 PaperColor (Spectra-6) accent color planes: 1-bit buffers with the
  // framebuffer's geometry/layout. A set bit recolors that pixel's ink (a
  // 0/black framebuffer bit) to the slot's `colorCode` on complete-waveform
  // refreshes; interrupted refreshes render it as plain ink (color pigments
  // never settle in a cut-off waveform), so accents appear only on standing
  // images. Up to 4 slots — the lowest slot with a set bit wins on overlap;
  // nullptr clears a slot; the caller owns the buffers. No-op on other panels.
  void setAccentPlaneSlot(uint8_t slot, const uint8_t* plane, uint8_t colorCode);
  // ED2208 Spectra-6 controller color codes for setAccentPlaneSlot().
  static constexpr uint8_t SPECTRA_BLACK = 0x0;
  static constexpr uint8_t SPECTRA_WHITE = 0x1;
  static constexpr uint8_t SPECTRA_YELLOW = 0x2;
  static constexpr uint8_t SPECTRA_RED = 0x3;
  static constexpr uint8_t SPECTRA_BLUE = 0x5;
  static constexpr uint8_t SPECTRA_GREEN = 0x6;

  // M5 PaperColor: interrupted-refresh cutoff (ms). The cut freezes the gate
  void setFastRefreshCutoffMs(uint16_t ms);
  // xteink-pokemon: see PanelDriver::setFastRefreshTuning (0, 0 = stock).
  void setFastRefreshTuning(uint8_t tsset, uint8_t pll);
  // xteink-pokemon: see PanelDriver::setFastRefreshDuScale (0 = built-in DU).
  void setFastRefreshDuScale(uint8_t percent);
  // xteink-pokemon: see PanelDriver::setFastRefreshDiffWindow.
  void setFastRefreshDiffWindow(bool on);
  // xteink-pokemon: the display SPI clock for a game (0 = the driver's default).
  // Call it with no refresh running.
  void setDisplaySpiHz(uint32_t hz);
  // xteink-pokemon: the last completed refresh's phases in microseconds: copy,
  // new plane, setup, waveform, old plane; then the bytes sent per plane and
  // the running counts of completed and skipped (unchanged) refreshes. False
  // where the driver does not measure them.
  bool lastRefreshTimings(uint32_t out[8]) const;
  // xteink-pokemon: see PanelDriver::pulseScan / pulseFinish / endPulseDrive.
  // The target is a framebuffer-layout image (1 white), `drive` a same-layout
  // mask (1 = drive this pixel); the window is in framebuffer rows and bytes.
  bool pulseScan(const uint8_t* target, const uint8_t* drive, uint16_t row0, uint16_t row1, uint16_t byte0,
                 uint16_t byte1, uint8_t frames, bool wait);
  void pulseFinish();
  void endPulseDrive();
  uint16_t fastRefreshCutoffMs() const;

  // Hold the periodic anti-ghost full refresh through a live interaction (slider
  // drag): while held, fast refreshes are never promoted to a full. Clear it and
  // force one full afterward to scrub any ghost. No-op on panels without the
  // periodic-full cadence (currently the EEGO A4's UC8279C driver).
  void setHoldPeriodicFullRefresh(bool hold);

  void begin();

  // Legacy compile-time dimensions kept for compatibility.
  static constexpr uint16_t DISPLAY_WIDTH = 800;
  static constexpr uint16_t DISPLAY_HEIGHT = 480;
  static constexpr uint16_t DISPLAY_WIDTH_BYTES = DISPLAY_WIDTH / 8;
  static constexpr uint32_t BUFFER_SIZE = DISPLAY_WIDTH_BYTES * DISPLAY_HEIGHT;
  static constexpr uint16_t X3_DISPLAY_WIDTH = 792;
  static constexpr uint16_t X3_DISPLAY_HEIGHT = 528;
  static constexpr uint16_t X3_DISPLAY_WIDTH_BYTES = X3_DISPLAY_WIDTH / 8;
  static constexpr uint32_t X3_BUFFER_SIZE = X3_DISPLAY_WIDTH_BYTES * X3_DISPLAY_HEIGHT;
  // Sized to the largest panel in the build — derived from the device set in the
  // registry (no device names here). One binary holds whichever panel is
  // runtime-selected; a single-device build gets exactly that panel's size.
  static constexpr uint32_t MAX_BUFFER_SIZE = BoardConfig::MAX_FRAMEBUFFER_BYTES;

  // Selected controller/backend identity; nullptr until a driver is selected by begin().
  // Read-only: never probes hardware or substitutes the board profile default.
  const char* getControllerName() const;

  // Runtime dimensions
  uint16_t getDisplayWidth() const { return displayWidth; }
  uint16_t getDisplayHeight() const { return displayHeight; }
  uint16_t getDisplayWidthBytes() const { return displayWidthBytes; }
  uint32_t getBufferSize() const { return bufferSize; }

  // Frame buffer operations
  void clearScreen(uint8_t color = 0xFF) const;
  void drawImage(const uint8_t* imageData, uint16_t x, uint16_t y, uint16_t w, uint16_t h,
                 bool fromProgmem = false) const;
  void drawImageTransparent(const uint8_t* imageData, uint16_t x, uint16_t y, uint16_t w, uint16_t h,
                            bool fromProgmem = false) const;
  // Persistent black/white output inversion. Framebuffers remain in their
  // normal logical colors, so callers keep drawing exactly as before; the
  // facade transforms frames only while sending them to the panel. The first
  // refresh after a mode change is automatically promoted from FAST to HALF
  // so single-buffer differential panels cannot compare opposite polarities.
  void setInverted(bool inverted);
  bool toggleInverted();
  bool isInverted() const { return _inverted; }
#ifndef EINK_DISPLAY_SINGLE_BUFFER_MODE
  void swapBuffers();
#endif
  void setFramebuffer(const uint8_t* bwBuffer) const;

  // X3 grayscale preconditioning settle pass, windowed to the gray region in
  // physical panel coordinates; call after the BW base frame is displayed and
  // before the grayscale planes are written. The no-arg overload settles the
  // full frame. No-op on panels that do not need it. See
  // Uc8253X3Driver::preconditionGrayscale.
  void preconditionGrayscale();
  void preconditionGrayscale(uint16_t x, uint16_t y, uint16_t w, uint16_t h);

  // Display the framebuffer as the base frame for a grayscale overlay that
  // follows. X3 uses the OEM differential base waveform; other panels display
  // normally with `fallback` mode. See PanelDriver::displayGrayscaleBase.
  void displayGrayscaleBase(RefreshMode fallback = HALF_REFRESH, bool turnOffScreen = false);
  // Starts a mode-bound pass. Absolute uploads must cover both complete planes
  // (full buffers or consecutive strips per plane) before displayGrayBuffer().
  // False means the requested mode is unavailable; no base was painted.
  bool displayGrayscaleBase(GrayscaleMode mode, RefreshMode fallback = HALF_REFRESH, bool turnOffScreen = false);
  void copyGrayscaleBuffers(const uint8_t* lsbBuffer, const uint8_t* msbBuffer);
  void copyGrayscaleLsbBuffers(const uint8_t* lsbBuffer);
  void copyGrayscaleMsbBuffers(const uint8_t* msbBuffer);
  enum GrayPlane { GRAY_PLANE_LSB, GRAY_PLANE_MSB };
  void writeGrayscalePlaneStrip(GrayPlane plane, const uint8_t* rows, uint16_t yStart, uint16_t numRows);
  // Current mode availability, including output inversion and base readiness.
  // A query does not alter the pending refresh or the plane encoding.
  GrayscaleCapabilities grayscaleCapabilities(GrayscaleMode mode = GrayscaleMode::Overlay) const;
  // Compatibility wrappers for Overlay mode.
  bool supportsBusyGrayscaleStaging() const;
  void prepareGrayscaleTarget();
  bool supportsStripGrayscale() const;
  // True when displayGrayscaleBase() defers the base activation so the gray
  // planes join it in one waveform (Paper Mono) - see PanelDriver.
  bool combinesGrayscaleBase() const;
  // Restore controller RAM and frameBuffer to the given BW baseline after
  // grayscale. Available in both buffer modes (CrossPoint's dual-buffer HAL
  // wraps it directly).
  void cleanupGrayscaleBuffers(const uint8_t* bwBuffer);
#ifndef EINK_DISPLAY_SINGLE_BUFFER_MODE
  // Restore controller RAM and frameBuffer to the BW baseline after grayscale.
  // frameBufferActive is the only valid source: the caller is always inside a
  // grayscale plane pass, which has left frameBuffer holding a PLANE, so there is
  // no fallback. With the secondary away (lent or released) the driver is told
  // there is no baseline and takes a clean sync on its next push. Call once per
  // page-turn after displayGrayBuffer() to ensure the next BW draw targets a
  // valid BW frame.
  void cleanupGrayscaleWithPreviousBuffer();
#endif

  void displayBuffer(RefreshMode mode = FAST_REFRESH, bool turnOffScreen = false);

  // Non-blocking refresh: pushes the frame, starts the panel waveform, and
  // returns (~25 ms) while the panel refreshes on its own (~0.3-2 s). Poll
  // refreshBusy(); the framebuffer is free to redraw the moment this returns
  // (the panel refreshes from its own RAM copy). Any blocking display call
  // waits out a pending async refresh first. In single-buffer mode this costs
  // one extra frame buffer (lazily heap-allocated) holding the last-displayed
  // frame as the differential baseline; if that allocation fails it falls
  // back to the blocking path.
  void displayBufferAsync(RefreshMode mode = FAST_REFRESH);
  // Async refresh without the single-buffer shadow (no extra RAM). The caller
  // promises (a) not to touch the framebuffer until the refresh completes
  // (waitRefreshComplete() / refreshBusy()==false / any blocking call), and
  // (b) to rebuild the controller's differential baseline itself before the
  // next differential update — e.g. the tiled-grayscale reader path, whose
  // cleanupGrayscaleBuffers() resyncs the baseline from the framebuffer.
  // In dual-buffer mode this is identical to displayBufferAsync().
  void displayBufferAsyncNoShadow(RefreshMode mode = FAST_REFRESH);
  // True while an async refresh is still running on the panel.
  bool refreshBusy();
  // Block until a pending refresh completes (no-op when none is): the async
  // window drains via the ISR edge wait (finishDisplayAsync), a trigger/complete
  // split via syncPendingAsync's displayFinish path.
  void waitRefreshComplete() {
    finishDisplayAsync();
    syncPendingAsync();
  }
  // True when the active driver's displayAsync() genuinely returns while the
  // panel refreshes; false where it falls back to a blocking refresh. Callers
  // can skip overlap scaffolding (e.g. whole-plane grayscale buffers) when
  // there is nothing to overlap.
  bool supportsAsyncRefresh() const;
  // End-of-frame idle power policy, currently Picco only. Call under the same
  // bus/render lock as drawing, after ALL grayscale uploads and cleanup.
  // Completes pending refreshes, then powers down analog circuitry, not RAM.
  void powerOffBetweenFrames();
  // True when the selected driver can use an ordinary deferred B/W refresh as
  // the base for a following grayscale pass.
  bool supportsAsyncGrayscaleBase() const;
  bool supportsDeferredGrayscaleBase() const;
  // Framebuffer must remain unchanged until waitRefreshComplete().
  bool displayGrayscaleBaseAsync(RefreshMode fallback = FAST_REFRESH);

  // ------------------------------------------------------------------------
  // CrossPoint EInkDisplay compatibility surface.
  //
  // These preserve the exact method names CrossPoint's HalDisplay / GfxRenderer
  // call, so that firmware builds unchanged through the EInkDisplay alias. Where
  // FreeInk's driver architecture already subsumes a CrossPoint optimization
  // (X4 RED-RAM baseline, single-buffer fast differential) the shim is a thin
  // state accessor; the real behavior lives in the driver.
  // ------------------------------------------------------------------------

  // Two-call refresh split. triggerDisplay() loads RAM and fires the waveform;
  // on X3 it returns while the ~130-770 ms waveform runs so the render task can
  // overlap non-SPI work, and completeDisplay() waits it out and performs the
  // post-waveform DTM1 sync + conditioning. On X4 the refresh completes inside
  // triggerDisplay() (short waveform, RED re-seeded inline) and completeDisplay()
  // is a no-op — matching CrossPoint's behavior. The framebuffer must not be
  // overwritten between the two calls; see PanelDriver::displayStart.
  void triggerDisplay(RefreshMode mode = FAST_REFRESH, bool turnOffScreen = false);
  void completeDisplay();

  // X4 async variant of the trigger/complete split (CrossPoint
  // EInkDisplay::triggerDisplayAsync/finishDisplayAsync). triggerDisplayAsync()
  // performs the full update (RAM writes, MASTER_ACTIVATION, buffer swap) but
  // returns while the waveform runs; finishDisplayAsync() sleeps until it
  // completes (busy-wait power/slice hooks active) and clears the pending
  // state. Between the calls the caller may do CPU/RAM-only work — the write
  // framebuffer is free (the swap already happened, the controller scans its
  // own RAM) — but must issue no display/bus operation; same-task contract as
  // triggerDisplay()/completeDisplay(). Every blocking display call self-heals
  // by waiting out an unfinished async refresh first (syncPendingAsync()).
  //
  // On X3, triggerDisplayAsync() falls back to triggerDisplay() — already
  // non-blocking there, with completeDisplay() as its finish — and
  // finishDisplayAsync() is a no-op.
  void triggerDisplayAsync(RefreshMode mode = FAST_REFRESH, bool turnOffScreen = false);
  void finishDisplayAsync();

  // True while a deferred refresh is in flight (any of the async/trigger entry
  // points until the finish/wait is consumed).
  bool isRefreshPending() const { return _refreshPending; }

  // Returns true (X4 only) when the controller's RED RAM holds the last-displayed
  // BW frame, i.e. a fast differential can diff against it. Always false on X3.
  // Diagnostic/advisory: FreeInk's SSD1677 driver keeps RED re-seeded after every
  // refresh, so the baseline is maintained without an explicit sync.
  bool isRedRamSynced() const { return _panelSel != PanelSel::X3 && _redRamSynced; }
  // Re-establish the X4 RED-RAM differential baseline from the displayed frame.
  // On FreeInk the SSD1677 driver already re-seeds RED after each single-buffer
  // refresh, so this only refreshes the advisory flag; kept for API parity.
  void syncRedRamFromFrameBuffer();

  // Opt in to X4 fast differential against the controller's retained RED-RAM baseline
  // while the secondary buffer is released. When set, a FAST refresh with no secondary
  // buffer keeps diffing against RED — the caller must have seeded it with
  // syncRedRamFromFrameBuffer() before releasing. When clear, such a FAST refresh
  // downgrades to HALF (see resolveReleasedMode) so it can't ghost off a stale baseline.
  void setSingleBufferFastDiff(bool enabled) { _singleBufferFastDiff = enabled; }
  bool singleBufferFastDiff() const { return _singleBufferFastDiff; }

  // X3-only: pick the fast (community) vs accurate (OEM) grayscale LUT bank.
  // FreeInk's X3 driver currently carries the single community `_gc` bank, so
  // this stores the preference for getFastGrayscaleLut() but does not yet switch
  // banks; see Uc8253X3Driver. No effect on X4.
  void setFastGrayscaleLut(bool fast) { _fastGrayscaleLut = fast; }
  bool getFastGrayscaleLut() const { return _fastGrayscaleLut; }

  // True when the runtime-selected panel is the Xteink X3 (X4 returns false).
  bool isX3Mode() const { return _panelSel == PanelSel::X3; }

  // EXPERIMENTAL: Windowed update - display only a rectangular region
  void displayWindow(uint16_t x, uint16_t y, uint16_t w, uint16_t h, bool turnOffScreen = false);
  void displayGrayBuffer(bool turnOffScreen = false, const unsigned char* lut = nullptr, bool factoryMode = false);
  void displayGrayCalibration(uint16_t customX, uint16_t customY, uint16_t customW, uint16_t customH);

  void refreshDisplay(RefreshMode mode = FAST_REFRESH, bool turnOffScreen = false);

  // Hint the X3 policy to run a one-shot full resync on next update.
  void requestResync(uint8_t settlePasses = 0);
  void skipInitialResync();
  void beginDisplayWork();
  void abortPostRefresh();
  bool postRefreshAborted() const;
  // True when the last display sequence actually reached the panel. Panels
  // which paint synchronously always report true, so refresh-cadence callers
  // behave exactly as before on them.
  bool displayCommitted() const;
  void runMaintenance();
  bool hasPendingMaintenance() const;
  void controllerIdle();

  // debug function
  void grayscaleRevert();

  // LUT control
  void setCustomLUT(bool enabled, const unsigned char* lutData = nullptr);

  // Power management
  void deepSleep();

  // Optional hooks fired around long BUSY waits (~0.3-2 s per refresh), so host
  // firmware can apply its own power policy (e.g. reduce the CPU clock) for the
  // wait window. Forwards to the bus, which owns every driver's busy-polling.
  // See EpdBus::setBusyWaitHooks for firing semantics.
  void setBusyWaitHooks(void (*beginHook)(), void (*endHook)()) { _bus.setBusyWaitHooks(beginHook, endHook); }

  // Optional slice hook replacing the BUSY poll delay once a wait has proven
  // long, so host firmware can sleep through the refresh instead of polling.
  // See EpdBus::setBusyWaitSliceHook for the contract.
  void setBusyWaitSliceHook(bool (*sliceHook)(int8_t busyPin, uint8_t busyLevel)) {
    _bus.setBusyWaitSliceHook(sliceHook);
  }

  // Access to frame buffer
  uint8_t* getFrameBuffer() const { return frameBuffer; }
  bool framebufferReady() const { return frameBuffer != nullptr; }

  // Copy the just-displayed frame (frameBufferActive) back into the write buffer.
  // displayBuffer() ends with swapBuffers(), so the write buffer would otherwise
  // hold the frame from two refreshes ago. Call this before patching a few regions
  // and re-displaying instead of fully re-rendering. No-op in single-buffer mode.
  void syncWriteBufferFromActive() const;

  // Release the framebuffer(s) — and the single-buffer async shadow — back to
  // the heap. After this call no display operations may be performed until
  // reallocBuffers() (or begin()) runs; the panel keeps showing its last
  // refreshed image. Two intended uses: transient sessions that reboot on
  // exit (e.g. a web UI), and lending ~48-100 KB to a memory-hungry phase
  // such as a chapter layout build. Safe no-op if already released.
  void releaseBuffers();

  // Reallocate after releaseBuffers(): buffers come back white (0xFF), so the
  // caller must fully redraw before the next display call. Returns false if
  // the heap cannot supply the buffers (the display is then unusable).
  bool reallocBuffers();

  // Lend the primary framebuffer's STORAGE to a transient in-heap build (a
  // chapter/catalog layout) WITHOUT freeing it. Unlike releaseBuffers() +
  // reallocBuffers(), the allocation never moves: freeing and re-mallocing
  // the 48 KB relocated it to a fresh heap position each cycle and
  // progressively fragmented the (PSRAM-less) heap until large arenas could
  // no longer be allocated. Here the caller borrows the framebuffer's own
  // bytes as build scratch; rendering is unavailable (getFrameBuffer() is
  // null) until returnBuildStorage(). Returns the buffer and its usable byte
  // length; null if already lent. Single-buffer path only (the C3 case).
  uint8_t* lendBuildStorage(uint32_t* sizeOut);

  // Reclaim the storage lent by lendBuildStorage(): re-enables rendering and
  // clears the framebuffer to white (the build overwrote it), so the caller
  // must fully redraw. Cannot fail (no allocation). No-op if not lent.
  void returnBuildStorage();

#ifndef EINK_DISPLAY_SINGLE_BUFFER_MODE
  // Release only the secondary (previous-frame) buffer to free ~48-52 KB
  // temporarily — e.g. during chapter compilation when no rendering is
  // happening. Available on every dual-buffer build (not just PSRAM ones):
  // CrossPoint's C3 lends the buffer out of internal DRAM. BW display keeps working.
  // Fast differential refresh continues only if the caller opts in with
  // setSingleBufferFastDiff(true) after seeding RED (syncRedRamFromFrameBuffer) just
  // before the release; the SSD1677 driver then diffs against — and re-seeds — the
  // controller's retained RED plane. Without the opt-in a FAST refresh downgrades to
  // HALF (resolveReleasedMode) so it can't ghost off a stale baseline. Grayscale AA is
  // unavailable until restored with reallocSecondaryBuffer(). No-op if already released.
  // Returns true if freed.
  bool releaseSecondaryBuffer();

  // Reallocate the secondary buffer after releaseSecondaryBuffer(). Seeds it
  // from the live framebuffer — the on-screen frame in released mode — so the
  // previously-displayed-frame contract holds and the next FAST refresh diffs
  // against a correct RED baseline (seeding white ghosts the first post-realloc
  // page; see the .cpp). Call BEFORE drawing the next frame into the
  // framebuffer. Returns true on success; false if malloc fails.
  bool reallocSecondaryBuffer();

  // Returns true if the secondary buffer is currently allocated.
  bool hasSecondaryBuffer() const;

  // Lend the secondary buffer's memory to the host WITHOUT freeing it: the
  // display drops to single-buffer mode exactly like releaseSecondaryBuffer()
  // (same fast-diff/refresh semantics apply), but the block stays owned here
  // and is handed to the caller for scratch use (e.g. a section-build arena).
  // Unlike release/realloc, the memory never enters the heap, so nothing can
  // allocate inside it and returnSecondaryBuffer() CANNOT fail — the
  // realloc-failure / fragmented-hole class of bugs is impossible by
  // construction. Returns nullptr if there is no secondary buffer or it is
  // already lent. *size receives the block size.
  uint8_t* borrowSecondaryBuffer(size_t* size);

  // Take the lent block back and restore dual-buffer mode. Seeds the buffer
  // from the live framebuffer and arms the one-shot RED-baseline handling,
  // identical to reallocSecondaryBuffer() (the build clobbered the contents).
  // Returns false only if nothing was lent.
  bool returnSecondaryBuffer();
#endif  // !EINK_DISPLAY_SINGLE_BUFFER_MODE

  // Save the current framebuffer to a PBM file (desktop/test builds only)
  void saveFrameBufferAsPBM(const char* filename);

 private:
  void selectDriver();
  // Shared body of drawImage()/drawImageTransparent(). transparent=true ANDs
  // (black-only); false overwrites. Handles non-byte-aligned x per-pixel.
  void blitImage(const uint8_t* imageData, uint16_t x, uint16_t y, uint16_t w, uint16_t h, bool fromProgmem,
                 bool transparent) const;
  // Block until a pending async refresh completes (no-op when none is).
  // Every blocking panel operation calls this before touching the bus.
  void syncPendingAsync();
  // Shared body of displayBufferAsync() / triggerDisplayAsync(): fire the
  // update and return while the waveform runs (_asyncPending set).
  void displayAsyncImpl(RefreshMode mode, bool turnOffScreen, bool noShadow = false);
  // One framebuffer-sized heap block (runtime panel's bufferSize, not
  // MAX_BUFFER_SIZE): PSRAM-first where available. Valid only after begin()
  // has seeded geometry / panel selection is final.
  uint8_t* allocFrameBufferStorage() const;
#ifndef EINK_DISPLAY_SINGLE_BUFFER_MODE
  // Downgrade a FAST request to HALF when the secondary (previous-frame) buffer is
  // released and the caller hasn't opted into single-buffer fast-diff — mirrors the
  // open-x4 EInkDisplay::triggerDisplay downgrade. X4 only; see the .cpp for rationale.
  RefreshMode resolveReleasedMode(RefreshMode mode) const;
#endif

  EpdBus _bus;
  PanelDriver* _driver = nullptr;

  // Async refresh state: pending flag + (single-buffer mode) a lazily
  // allocated shadow of the last-displayed frame, used as the differential
  // baseline while the app redraws the live framebuffer. _shadowValid drops
  // whenever a blocking display path runs (the controller RAM then holds the
  // baseline again).
  // One pending flag for every deferred refresh (X4 async fire, X3 split);
  // drained by syncPendingAsync() through the driver's displayFinish().
  GrayscaleMode _grayscaleMode = GrayscaleMode::Overlay;
  uint16_t _grayRows[2] = {0, 0};
  bool _grayPassFailed = false;
  void cancelGrayscalePass();
  bool acceptGrayscaleRows(unsigned plane, const uint8_t* data, uint16_t y, uint16_t rows);
  bool _refreshPending = false;
  uint8_t* _asyncShadow = nullptr;
  bool _shadowValid = false;
#ifdef EINK_DISPLAY_SINGLE_BUFFER_MODE
  // Frame submitted to the pending update: the shadow for redraw-safe async,
  // or the live frame for entry points requiring it to remain untouched.
  const uint8_t* _pendingSingleBufferFrame = nullptr;
#endif
  bool _buildLent = false;  // framebuffer storage lent to a build (see lendBuildStorage)

#ifndef EINK_DISPLAY_SINGLE_BUFFER_MODE
  // Secondary buffer lent to the host (see borrowSecondaryBuffer): the block
  // this points at is still owned by frameBuffer0/1; frameBufferActive is null
  // while lent so all released-mode display semantics apply unchanged.
  uint8_t* _secondaryLent = nullptr;
  // One-shot, armed by reallocSecondaryBuffer(): the controller's RED RAM still
  // holds the on-screen frame (host allocation never touches controller RAM),
  // while the fresh secondary may not — the host may have scribbled or cleared
  // the framebuffer between release and realloc (blocking section builds do:
  // image warm + clearScreen before the realloc), so the seed copied there is
  // unproven. The next full-frame FAST must diff against the retained RED
  // baseline (prev = nullptr, single-buffer path; the driver's post-refresh
  // resync then re-establishes BW/RED from the displayed frame) instead of
  // pushing the unproven secondary into RED — pushing a wrong baseline leaves
  // undriven pixels: a baked-in ghost of whatever the panel showed (e.g. the
  // indexing popup) until the next absolute waveform. A non-fast update
  // rewrites RED absolutely anyway and just clears the flag.
  bool _redBaselineAuthoritative = false;
  // Consume the one-shot for a full-frame update: returns the prev pointer the
  // driver should diff against for `effectiveMode`.
  const uint8_t* consumePrevFrameFor(RefreshMode effectiveMode);
#endif

  enum class PanelSel : uint8_t { X4, X3, M5 };
  PanelSel _panelSel = PanelSel::X4;

  // CrossPoint compatibility state (see the compatibility surface above).
  // _redRamSynced mirrors whether the X4 RED-RAM baseline is current (advisory);
  // the other two are caller preferences echoed back to CrossPoint's HAL.
  bool _redRamSynced = false;
  bool _singleBufferFastDiff = false;
  bool _fastGrayscaleLut = false;
  bool _inverted = false;
  bool _inversionDirty = false;

  // Runtime display geometry (seeded from the driver at begin()).
  uint16_t displayWidth = DISPLAY_WIDTH;
  uint16_t displayHeight = DISPLAY_HEIGHT;
  uint16_t displayWidthBytes = DISPLAY_WIDTH_BYTES;
  uint32_t bufferSize = BUFFER_SIZE;

  // Frame buffer (facade-owned), heap-allocated in begin() on every build:
  // PSRAM-first on devices with it (see FREEINK_FB_PSRAM in BoardConfig.h),
  // internal DRAM otherwise. Heap-backed even without PSRAM so hosts with a
  // single tight heap (ESP32-C3) can lend the buffer out via
  // releaseBuffers()/reallocBuffers() during memory-hungry phases.
  uint8_t* frameBuffer0 = nullptr;
  uint8_t* frameBuffer = nullptr;
#ifndef EINK_DISPLAY_SINGLE_BUFFER_MODE
  uint8_t* frameBuffer1 = nullptr;
  uint8_t* frameBufferActive = nullptr;
#endif
};

}  // namespace freeink
